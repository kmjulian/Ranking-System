<?php

class C_District extends CI_Controller
{
	function __construct()
    {
        parent:: __construct();
        $this->load->model('cdistrict_model');
        $this->load->model('user_model');
    }

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'Admin' || $position == 'admin')
		{
			$this->load->view('dashboard/header_view');
			$this->load->view('dashboard/c_district_view');
			
		} 
		else
		{
			redirect('login','refresh');
		}
		
	}


	function create_district_acct()
	{

		$this->form_validation->set_rules('username', 'Username', 'trim|required|is_unique[user.user_username]');
		$this->form_validation->set_message('is_unique', 'username already exist!');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|is_unique[district.District_Email]');
		$this->form_validation->set_message('is_unique', '%s already exists!');

		if($this->form_validation->run() == FALSE)
        {   
            redirect('c_district', 'refresh');           
        }
        else
        {
        	$username = $this->input->post('username');
			$password = $this->input->post('password');
			$fname = $this->input->post('fname');
			$mname = $this->input->post('mname');
			$lname = $this->input->post('lname');
			$pnumber = $this->input->post('number');
			$email = $this->input->post('email');
			$gender = $this->input->post('gender');
			$region = $this->input->post('region');
			$province = $this->input->post('province');
			$city = $this->input->post('city');
			$zip = $this->input->post('zip');
			$lot = $this->input->post('lot');
			$barangay = $this->input->post('barangay');

			$acct_details = array(
				'user_username' => $username,
				'user_password' => $password,
				'user_position' => 'District'
			);

			$district_details = array(
				'District_Fname' => $fname,
				'District_Mname' => $mname,
				'District_Lname' => $lname,
				'District_Pnumber' => $pnumber,
				'District_Gender' => $gender,
				'District_Email' => $email,
				'District_Lot' => $lot,
				'District_Barangay' => $barangay,
				'District_City' => $city,
				'District_Zip' => $zip,
				'District_Province' => $province
				
			);
			
			$this->cdistrict_model->create_district_acct($acct_details);
			$this->cdistrict_model->insert_district_details($district_details);
        }

	}
}