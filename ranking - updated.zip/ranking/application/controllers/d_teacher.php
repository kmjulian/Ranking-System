<?php

class D_Teacher extends CI_Controller
{
	function index()
	{
		$this->load->view('district/header_view');
		$this->load->view('district/d_teacher_view');
		
	}
}