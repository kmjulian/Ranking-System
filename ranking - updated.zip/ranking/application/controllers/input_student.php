<?php


class Input_Student extends CI_Controller
{
	public function __construct()
    {
        parent:: __construct();
        $this->load->model('user_model');
        $this->load->model('input_nat_model');
    }

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'Admin' || $position == 'admin')
		{
			$data['student_details'] = $this->input_nat_model->select_student();
			$this->load->view('dashboard/header_view');
			$this->load->view('dashboard/input_student_view', $data);
			$this->load->view('dashboard/footer_view');	
		}
		else
		{
			redirect('login', 'refresh');
		}	
	}



}