<?php

class District extends CI_Controller
{
	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'District' || $position == 'district')
		{
			
			$this->load->view('district/header_view');
			$this->load->view('district/district_view');
			$this->load->view('district/footer_view');
	
		}
		else
		{
			redirect('login', 'refresh');
		}	
	}

}