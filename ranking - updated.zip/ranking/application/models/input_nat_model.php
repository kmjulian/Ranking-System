<?php

class Input_Nat_Model extends CI_Model
{
	public function __construct()
	{
		parent:: __construct();
	}	

	function select_student()
	{
		$this->db->select("Student_ID, Student_Fname");
		$this->db->from("student");
		$query = $this->db->get();
		return $query->result_array();

	}
}