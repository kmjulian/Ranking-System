<?php 

class V_Student_Model extends CI_Model
{
	public function __construct()
	{
		parent:: __construct();
	}

	function select_accts()
	{
		$this->db->select('s.Student_ID, u.user_id, s.Student_Fname');
		$this->db->from('student AS s');
		$this->db->join('user AS u', 'u.user_id = s.user_id');
		$query = $this->db->get();
		return $query->result_array();
	}
}