<?php include'header.php'; ?>
<div class="content-wrapper">
    <div class="container-fluid">

      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <!-- <a href="#">Student Accounts</a> -->
          <i class="fa fa-user"></i> Adviser Accounts
        </li>
       
      </ol>

      	<div class="container">
                <div class="table-responsive">
                     <table id="employee_data" class="table table-hover table-bordereds" > 
                     	<thead>
      		<tr>
      			<td>Adviser ID</td>
      			<td>User ID</td>
      			<td>First Name</td>
      		</tr>
      	</thead>
      		<tr>
      			<td></td>
      			<td></td>
      			<td></td>
      		</tr>

      	</table>
  </div>
</div>
</div>
</div>

<?php include'footer.php'; ?>