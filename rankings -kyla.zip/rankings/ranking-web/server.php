<?php
include 'application/config/database.php';
session_start();
$uname='';
$fname='';
$lname='';
$email='';
$errors = array();

		if (isset($_REQUEST['login'])) {

 		 $uname = $dbcon->real_escape_string($_POST['uname']);
 		 $ppass = $dbcon->real_escape_string($_POST['pword']);

		  if (count($errors) == 0) {
 		 	$query = "SELECT * FROM user WHERE user_username='$uname' AND user_password='$ppass'";
 		 	$results = $dbcon->query($query);

  				$row=$results->fetch_assoc();
			
  				$row=$row['user_position'];


  			if (mysqli_num_rows($results) == 1) {

  				if ($uname == "admin") {
  					$_SESSION['uname'] = $uname;
  			  header('location: application/index.php');
  				}
  				elseif
  					($uname == "student"){ 
  					$_SESSION['uname'] = $uname;
  			  header('location: application/student_page/index.php');

  				}elseif
  					($uname == "teacher") {

  					$_SESSION['uname'] = $uname;
  			  header('location: application/subject_teacher/index.php');
  				}
  				
  			}
  			else {
  				array_push($errors, "Wrong username/password combination");
  			}
  }

}

?>