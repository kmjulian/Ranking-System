
<?php require'server.php';
?>
<html>
<body>
<br>
		<center><h1>CEU</h1></center>
			<form action="" method="post">
				<center>
						<?php include'error.php';?>
				<input type="text" name="uname" placeholder="Username"><br><br>
				<input type="text" name="fname" placeholder="First name"><br><br>
				<input type="text" name="lname" placeholder="Last name"><br><br>
				<input type="email" name="email" placeholder="Email"><br><br>
				<input type="password" name="pword" placeholder="Password"><br><br>
				<input type="password" name="cword" placeholder="Confirm Password"><br><br>
				Already have an account? <br><a href="login.php">Sign in here!</a><br><br>
				<input type="submit" name="register" value="Register">
				</center>
			</form>
</body>

</html>

