<?php 
  session_start(); 

  if (!isset($_SESSION['uname'])) {
  		$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  else{
    $username= $_SESSION['uname'];
  }

  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['uname']);
  	header("location: login.php");
  }
?>
