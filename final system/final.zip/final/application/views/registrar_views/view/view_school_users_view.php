<div class="content-wrapper">
    <section class="content-header">
    </section>
    <section class="content">
    	<?php echo "view school users"; ?>
    </section>
</div>