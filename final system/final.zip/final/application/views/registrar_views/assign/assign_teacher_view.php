<div class="content-wrapper">
    <section class="content-header">
    </section>
    <section class="content">
    	<?php echo "assign teacher"; ?>
    </section>
</div>