<div class="content-wrapper">
    <section class="content-header">
    </section>
    <section class="content">
    	<?php echo "principal home"; ?>
    </section>
</div>