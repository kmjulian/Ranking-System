<?php 

class V_District_Model extends CI_Model
{
	public function __construct()
	{
		parent:: __construct();
	}

	function select_accts()
	{
		$this->db->select('di.District_ID, u.user_id, di.District_Fname');
		$this->db->from('district AS di');
		$this->db->join('user AS u', 'u.user_id = di.user_id');
		$query = $this->db->get();
		return $query->result_array();
	}
}