<?php 

class V_Teacher_Model extends CI_Model
{
	public function __construct()
	{
		parent:: __construct();
	}

	function select_accts()
	{
		$this->db->select('t.Teacher_ID, u.user_id, t.Teacher_Fname');
		$this->db->from('Teacher AS t');
		$this->db->join('user AS u', 'u.user_id = t.user_id');
		$query = $this->db->get();
		return $query->result_array();
	}
}