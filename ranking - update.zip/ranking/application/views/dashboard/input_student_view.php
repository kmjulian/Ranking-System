<div class="content-wrapper">
	<div class="container-fluid">

	<ol class="breadcrumb" style="margin-top: 10px">
  		<li class="breadcrumb-item">
  			<a href="#">Dashboard</a>
  		</li>

  		<li class="breadcrumb-item active">
  			"Input Results"
  		</li>
  	</ol>

  <div class="container">
  	<h1 class="well">NAT Results</h1>
	<div class="col-lg-12 well">
		<div class="container">
			<div class="row">
				<?php echo form_open('input_student');?>
						<div class="form-group">
							<select name="student" class="form-control">
                  				<option selected="true" disabled="disabled">-- Select Student --</option>
                  				<?php foreach($student_details as $row): ?>
									<option value="<?= $row['Student_Fname']?>"><?= $row['Student_Fname'] ?></option>
								<?php endforeach; ?>
                			</select>
						</div>
					
						<div class="form-group">
							<label>Filipino</label>
                			<input type="text" placeholder="(ex. 100" name="filipino" class="form-control">
						</div>	
						<div class="form-group">
							<label>Araling Panlipunan</label>
                			<input type="text" placeholder="(ex. 50" name="ap" class="form-control">
						</div>	
						<div class="form-group">
							<label>Math</label>
                			<input type="text" placeholder="(ex. 60" name="math" class="form-control">
						</div>	
						<div class="form-group">
							<label>Science</label>
                			<input type="text" placeholder="(ex. 70" name="science" class="form-control">
						</div>	
						<div class="form-group">
							<label>English</label>
                			<input type="text" placeholder="(ex. 80" name="english" class="form-control">
						</div>	
						<div class="form-group">
							<label>CTST</label>
                			<input type="text" placeholder="(ex. 90" name="ctst" class="form-control">
						</div>	
						<button type="submit" class="btn btn-info btn-lg" data-toggle="modal" data-target="#success">Submit</button>	
				<?php echo form_close();?>
			</div>
		</div>
	</div>
</div>