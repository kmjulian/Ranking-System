<div class="content-wrapper">
  <div class="container-fluid"> 
  <!-- Breadcrumbs-->
  <ol class="breadcrumb" style="margin-top: 10px">
    <li class="breadcrumb-item">
      <a href="admin">Dashboard</a>
    </li> 
    <li class="breadcrumb-item active">
      View District Account
    </li>
  </ol>

  <div class="container">
	<div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> District Accounts</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                      <th>District ID</th>
                      <th>User ID</th>
                      <th>First Name</th>
                    </tr>
                  </thead>

            <?php foreach($list as $row): ?>
                <tbody>
                <tr>
                  <td><?= $row['District_ID']?></td>
                  <td><?= $row['user_id']?></td>
                  <td><?= $row['District_Fname']?></td>
                </tr>
             <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
    </div>

</div>