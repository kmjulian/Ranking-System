<?php

class Teacher extends CI_Controller
{
	
		function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'Teacher' || $position == 'teacher')
		{
			$this->load->view('teacher/header_view');
			$this->load->view('teacher/teacher_view');
			$this->load->view('teacher/footer_view');	
		}
		else
		{
			redirect('login', 'refresh');
		}	
	}
	
}