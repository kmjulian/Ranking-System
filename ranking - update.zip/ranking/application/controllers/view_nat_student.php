<?php


class View_Nat_Student extends CI_Controller
{
	public function __construct()
    {
        parent:: __construct();
        
        $this->load->model('user_model');
    }

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'Student' || $position == 'student')
		{
			
			$this->load->view('student/header_view');
			$this->load->view('student/student_view');
			$this->load->view('student/footer_view');	
		}
		else
		{
			redirect('login', 'refresh');
		}	
	}



}