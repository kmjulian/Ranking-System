<?php

class Student extends CI_Controller
{
	
	

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'Student' || $position == 'student')
		{
			$this->load->view('student/header_view');
			$this->load->view('student/student_view');
		
		}
		else
		{
			redirect('login', 'refresh');
		}	
	}

}