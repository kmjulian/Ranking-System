<?php

class dTables extends CI_Controller
{
	function index()
	{
		$this->load->view('tables/header_view-d');
		$this->load->view('tables/tables_view-d');
		
	}
}