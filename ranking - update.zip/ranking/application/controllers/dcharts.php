<?php

class dCharts extends CI_Controller
{
	function index()
	{
		$this->load->view('charts/header_view-d');
		$this->load->view('charts/charts_view-d');
		
	}
}