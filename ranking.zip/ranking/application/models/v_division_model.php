<?php 

class V_Division_Model extends CI_Model
{
	public function __construct()
	{
		parent:: __construct();
	}

	function select_accts()
	{
		$this->db->select('d.Division_ID, u.user_id, d.Division_Fname');
		$this->db->from('division AS d');
		$this->db->join('user AS u', 'u.user_id = d.user_id');
		$query = $this->db->get();
		return $query->result_array();
	}
}