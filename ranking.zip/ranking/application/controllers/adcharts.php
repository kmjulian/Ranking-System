<?php

class adCharts extends CI_Controller
{
	function index()
	{
		$this->load->view('dashboard/header_view-admin');
		$this->load->view('dashboard/charts_view-admin');
		
	}
}