<?php

class Teacher extends CI_Controller
{
	function index()
	{
		$this->load->view('teacher/header_view');
		$this->load->view('teacher/teacher_view');
		
	}
}