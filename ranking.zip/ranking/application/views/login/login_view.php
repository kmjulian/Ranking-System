<div class="container bg">
	<div class="row">
		<center><div class="col-md-4 col-sm-4 col-xs-12" style="padding-left: 100px; padding-right: 100px; width:500px; height: 500px;">

		<form class="form-container" method="post" action="?">
				<center><h2>Login</h2></center>

				<center><div class="form-group">
					<label class="form-group">Username</label>
					<div class="form-controls">
						<input type="text" name="username" class="input-xlarge"/>
					</div>
				</div></center>

				<center><div class="form-group">
					<label class="form-group">Password</label>
					<div class="form-controls">
						<input type="password" name="password" class="input-xlarge"/>
					</div>
				</div></center>

				<div class="checkbox" style="text-align: left; padding-left: 70px;">
					<label>
						<input type="checkbox">Remember Me
					</label>
				</div>

				<center><div class="form-group">
					<div class="form-controls">
						<input type="submit" value="Login" class="btn btn-primary"/>
					</div>
				</div></center>

			</form>
		</div></center>
	</div>
</div>