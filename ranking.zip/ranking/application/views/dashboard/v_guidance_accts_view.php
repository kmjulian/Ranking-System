<div class="content-wrapper">
	<div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i>  Guidance Accounts</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                      <th>Guidance ID</th>
                      <th>User ID</th>
                      <th>First Name</th>
                    </tr>
                  </thead>

            <?php foreach($list as $row): ?>
                <tbody>
                <tr>
                  <td><?= $row['Guidance_ID']?></td>
                  <td><?= $row['user_id']?></td>
                  <td><?= $row['Guidance_Fname']?></td>
                </tr>
             <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
    </div>

</div>