<div class="content-wrapper">
	<div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i>  Division Accounts</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                      <th>Division ID</th>
                      <th>User ID</th>
                      <th>First Name</th>
                    </tr>
                  </thead>

            <?php foreach($list as $row): ?>
                <tbody>
                <tr>
                  <td><?= $row['Division_ID']?></td>
                  <td><?= $row['user_id']?></td>
                  <td><?= $row['Division_Fname']?></td>
                </tr>
             <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
    </div>

</div>