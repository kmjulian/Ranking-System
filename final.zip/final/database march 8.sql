-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2018 at 09:29 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final`
--

-- --------------------------------------------------------

--
-- Table structure for table `guidance`
--

CREATE TABLE `guidance` (
  `guidance_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `guidance_fname` varchar(20) NOT NULL,
  `guidance_mname` varchar(20) NOT NULL,
  `guidance_lname` varchar(20) NOT NULL,
  `guidance_district` varchar(10) NOT NULL,
  `guidance_address` varchar(50) NOT NULL,
  `guidance_email` varchar(20) NOT NULL,
  `guidance_contact` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `principal`
--

CREATE TABLE `principal` (
  `principal_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `school_id` int(11) NOT NULL,
  `principal_fname` varchar(20) NOT NULL,
  `principal_mname` varchar(20) NOT NULL,
  `principal_lname` varchar(20) NOT NULL,
  `principal_district` varchar(30) NOT NULL,
  `principal_address` varchar(50) NOT NULL,
  `principal_email` varchar(30) NOT NULL,
  `principal_contact` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `principal`
--

INSERT INTO `principal` (`principal_id`, `user_id`, `school_id`, `principal_fname`, `principal_mname`, `principal_lname`, `principal_district`, `principal_address`, `principal_email`, `principal_contact`) VALUES
(1, 3, 8, 'Jan', 'Llantos', 'Sy', '3', 'Park Avenue, Pasay City', 'jan@principal', '1234567'),
(2, 4, 9, 'Aleo', 'Ralph', 'De Leon', '3', 'Vito Cruz, Manila', 'aleo@principal', '1234567');

-- --------------------------------------------------------

--
-- Table structure for table `registrar`
--

CREATE TABLE `registrar` (
  `registrar_id` int(10) NOT NULL,
  `user_id` int(20) NOT NULL,
  `school_id` int(11) NOT NULL,
  `registrar_fname` varchar(20) NOT NULL,
  `registrar_mname` varchar(20) NOT NULL,
  `registrar_lname` varchar(20) NOT NULL,
  `registrar_district` varchar(30) NOT NULL,
  `registrar_address` varchar(40) NOT NULL,
  `registrar_email` varchar(30) NOT NULL,
  `registrar_contact` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrar`
--

INSERT INTO `registrar` (`registrar_id`, `user_id`, `school_id`, `registrar_fname`, `registrar_mname`, `registrar_lname`, `registrar_district`, `registrar_address`, `registrar_email`, `registrar_contact`) VALUES
(1, 2, 8, 'Katherine', 'Llantos', 'Sy', '3', 'Park Avenue, Pasay City', 'kath@registrar', '1234567'),
(2, 5, 9, 'Wyatt', 'Zeus', 'Holgado', '3', 'Park Avenue, Pasay City', 'wyatt@registrar', '1234567');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `school_id` int(11) NOT NULL,
  `school_name` varchar(50) NOT NULL,
  `school_contact` varchar(20) NOT NULL,
  `school_address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`school_id`, `school_name`, `school_contact`, `school_address`) VALUES
(8, 'Bangkal Main Elementary School', '4747424', 'Malvar, Bangkal'),
(9, 'Bangkal Elementary School 2', '7878473', 'Lim, Bangkal');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `section_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `grade_level` varchar(10) NOT NULL,
  `section_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`section_id`, `school_id`, `grade_level`, `section_name`) VALUES
(1, 8, 'Grade 2', '1-Magaling'),
(2, 8, 'Grade 2', '2 - Matalino'),
(3, 8, 'Grade 2', '3 - Maunawain');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `student_fname` varchar(20) NOT NULL,
  `student_mname` varchar(20) NOT NULL,
  `student_lname` varchar(20) NOT NULL,
  `student_district` varchar(20) NOT NULL,
  `student_address` varchar(50) NOT NULL,
  `student_email` varchar(20) NOT NULL,
  `student_contact` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `teacher_fname` varchar(20) NOT NULL,
  `teacher_mname` varchar(20) NOT NULL,
  `teacher_lname` varchar(20) NOT NULL,
  `teacher_district` varchar(10) NOT NULL,
  `teacher_address` varchar(50) NOT NULL,
  `teacher_email` varchar(20) NOT NULL,
  `teacher_contact` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_username` varchar(20) NOT NULL,
  `user_password` varchar(20) NOT NULL,
  `user_position` varchar(20) NOT NULL,
  `school_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_username`, `user_password`, `user_position`, `school_id`, `section_id`) VALUES
(1, 'district', 'pass', 'district', 0, 0),
(2, 'mainregistrar', 'pass', 'Registrar', 8, 0),
(3, 'mainprincipal', 'pass', 'Principal', 8, 0),
(4, '2principal', 'pass', 'Principal', 9, 0),
(5, '2registrar', 'pass', 'Registrar', 9, 0),
(6, 'test1', 'pass', 'Student', 8, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `guidance`
--
ALTER TABLE `guidance`
  ADD PRIMARY KEY (`guidance_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`);

--
-- Indexes for table `principal`
--
ALTER TABLE `principal`
  ADD PRIMARY KEY (`principal_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`);

--
-- Indexes for table `registrar`
--
ALTER TABLE `registrar`
  ADD PRIMARY KEY (`registrar_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`school_id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`section_id`),
  ADD KEY `school_id` (`school_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `section_id` (`section_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `section_id` (`section_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `section_id` (`section_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `guidance`
--
ALTER TABLE `guidance`
  MODIFY `guidance_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `principal`
--
ALTER TABLE `principal`
  MODIFY `principal_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `registrar`
--
ALTER TABLE `registrar`
  MODIFY `registrar_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `school`
--
ALTER TABLE `school`
  MODIFY `school_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `guidance`
--
ALTER TABLE `guidance`
  ADD CONSTRAINT `guidance_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `principal`
--
ALTER TABLE `principal`
  ADD CONSTRAINT `principal_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `registrar`
--
ALTER TABLE `registrar`
  ADD CONSTRAINT `registrar_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
