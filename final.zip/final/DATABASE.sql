-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2018 at 09:58 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final`
--

-- --------------------------------------------------------

--
-- Table structure for table `guidance`
--

CREATE TABLE `guidance` (
  `guidance_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `guidance_fname` varchar(20) NOT NULL,
  `guidance_mname` varchar(20) NOT NULL,
  `guidance_lname` varchar(20) NOT NULL,
  `guidance_district` varchar(10) NOT NULL,
  `guidance_address` varchar(50) NOT NULL,
  `guidance_email` varchar(20) NOT NULL,
  `guidance_contact` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guidance`
--

INSERT INTO `guidance` (`guidance_id`, `user_id`, `school_id`, `guidance_fname`, `guidance_mname`, `guidance_lname`, `guidance_district`, `guidance_address`, `guidance_email`, `guidance_contact`) VALUES
(4, 26, 10, 'Christian', 'Villianueva', 'Profeta', '3', 'Quirino, Metro Manila', 'christian@guidance', '4747504'),
(5, 30, 11, 'Tyrone', 'Almeda', 'Fonacier', '3', 'Cabrera, Pasay', 'tyrone@guidance', '4747505');

-- --------------------------------------------------------

--
-- Table structure for table `mdl_quiz_grades`
--

CREATE TABLE `mdl_quiz_grades` (
  `id` int(11) NOT NULL,
  `quiz` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `grade` int(11) NOT NULL,
  `timemodified` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mdl_quiz_grades`
--

INSERT INTO `mdl_quiz_grades` (`id`, `quiz`, `userid`, `grade`, `timemodified`) VALUES
(1, 6, 3, 10, 1520580014),
(2, 16, 3, 5, 1520922322);

-- --------------------------------------------------------

--
-- Table structure for table `principal`
--

CREATE TABLE `principal` (
  `principal_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `school_id` int(11) NOT NULL,
  `principal_fname` varchar(20) NOT NULL,
  `principal_mname` varchar(20) NOT NULL,
  `principal_lname` varchar(20) NOT NULL,
  `principal_district` varchar(30) NOT NULL,
  `principal_address` varchar(50) NOT NULL,
  `principal_email` varchar(30) NOT NULL,
  `principal_contact` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `principal`
--

INSERT INTO `principal` (`principal_id`, `user_id`, `school_id`, `principal_fname`, `principal_mname`, `principal_lname`, `principal_district`, `principal_address`, `principal_email`, `principal_contact`) VALUES
(3, 21, 10, 'Royce', 'Ruel', 'Aquino', '3', 'Park Avenue, Pasay', 'royce@principal', '4747501'),
(4, 22, 11, 'Kyla', 'Joy', 'Julian', '3', 'Comembo, Makati', 'kyla@principal', '4747502');

-- --------------------------------------------------------

--
-- Table structure for table `registrar`
--

CREATE TABLE `registrar` (
  `registrar_id` int(10) NOT NULL,
  `user_id` int(20) NOT NULL,
  `school_id` int(11) NOT NULL,
  `registrar_fname` varchar(20) NOT NULL,
  `registrar_mname` varchar(20) NOT NULL,
  `registrar_lname` varchar(20) NOT NULL,
  `registrar_district` varchar(30) NOT NULL,
  `registrar_address` varchar(40) NOT NULL,
  `registrar_email` varchar(30) NOT NULL,
  `registrar_contact` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrar`
--

INSERT INTO `registrar` (`registrar_id`, `user_id`, `school_id`, `registrar_fname`, `registrar_mname`, `registrar_lname`, `registrar_district`, `registrar_address`, `registrar_email`, `registrar_contact`) VALUES
(3, 23, 10, 'Wyatt', 'Zeus', 'Holgado', '3', 'Park Avenue, Pasay', 'wyatt@registrar', '4747503'),
(4, 24, 11, 'Hans', 'DV', 'Villanueva', '3', 'Decena St., Pasay', 'hans@registrar', '4747504');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `school_id` int(11) NOT NULL,
  `school_name` varchar(50) NOT NULL,
  `school_contact` varchar(20) NOT NULL,
  `school_address` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`school_id`, `school_name`, `school_contact`, `school_address`) VALUES
(10, 'Bangkal Main Elementary School', '4747424', 'Malvar, Bangkal'),
(11, 'Bangkal Elementary School 2', '4747425', 'Lim, Bangkal');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `section_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `grade_level` varchar(10) NOT NULL,
  `section_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`section_id`, `school_id`, `grade_level`, `section_name`) VALUES
(10, 11, 'Grade 2', 'I - Juan'),
(11, 11, 'Grade 2', 'II - Timoteo'),
(12, 11, 'Grade 3', 'I - Samuel'),
(13, 11, 'Grade 3', 'II - Mateo'),
(14, 11, 'Grade 4', 'I - Hosea'),
(15, 11, 'Grade 4', 'II - Ezra'),
(16, 11, 'Grade 2', 'I - Jonas'),
(17, 11, 'Grade 2', 'II - Daniel'),
(18, 11, 'Grade 3', 'I - Isaias'),
(19, 11, 'Grade 3', 'II - Pedro'),
(20, 11, 'Grade 4', 'I - Santiago'),
(21, 11, 'Grade 4', 'II - Job');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `student_fname` varchar(20) NOT NULL,
  `student_mname` varchar(20) NOT NULL,
  `student_lname` varchar(20) NOT NULL,
  `student_district` varchar(20) NOT NULL,
  `student_address` varchar(50) NOT NULL,
  `student_email` varchar(20) NOT NULL,
  `student_contact` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `user_id`, `school_id`, `section_id`, `student_fname`, `student_mname`, `student_lname`, `student_district`, `student_address`, `student_email`, `student_contact`) VALUES
(7, 43, 10, 10, 'Nathan', 'Po', 'Munar', '3', 'Makati, Metro Manila', 'nathan@student', '09367859008'),
(8, 44, 10, 10, 'Samantha', 'Adriano', 'Sarmiento', '3', 'Bangkal, Makati', 'samantha@student', '09365780965'),
(9, 45, 10, 10, 'Patricia', 'Vito', 'Reyes', '3', 'Evangelista, Pasay', 'patricia@student', '09098764545'),
(10, 46, 10, 10, 'Steph', 'Avillo', 'Marquez', '3', 'Makati, Metro Manila', 'steph@student', '09550981234'),
(11, 47, 10, 10, 'Aika', 'Reyes', 'Ricardo', '3', 'Makati, Metro Manila', 'aika@student', '09123456787'),
(12, 48, 10, 10, 'Marvin', 'Jade', 'Ferrero', '3', 'Pembo, Makati', 'marvin@student', '09552340978'),
(13, 49, 10, 10, 'Francine', 'Vergara', 'Alfafara', '3', 'Comembo, Makati', 'francine@student', '09957890909'),
(14, 50, 10, 10, 'Charmaine', 'Masa', 'Caesar', '3', 'Cailles, Bangkal', 'charmaine@student', '09564563423'),
(15, 51, 10, 10, 'Frank', 'Sol', 'Klein', '3', 'Park Avenue, Pasay', 'frank@student', '09085674545'),
(16, 52, 10, 10, 'Adam', 'Moris', 'Laveign', '3', 'Vito Cruz, Manila', 'adam@student', '09056785645'),
(17, 53, 10, 11, 'Sherine', 'Toon', 'Link', '3', 'Park Avenue, Pasay', 'sherine@student', '09304456768'),
(18, 54, 10, 11, 'Darrel', 'Sky', 'Jaojoco', '3', 'Evangelista, Pasay', 'darrel@student', '09556780998'),
(19, 55, 10, 11, 'Empress', 'Sook', 'Welch', '3', 'Pembo, Makati', 'empress@student', '09123456745'),
(20, 56, 10, 11, 'Adrian', 'Gapar', 'Alcantara', '3', 'Pembo, Makati', 'adrian@student', '09123456787'),
(21, 57, 10, 11, 'Zach', 'Lopez', 'Monay', '3', 'Cailles, Bangkal', 'zach@student', '09096785645'),
(22, 58, 10, 11, 'Mariz', 'Juan', 'Revillame', '3', 'Cabrera, Pasay', 'mariz@student', '09123486709'),
(23, 59, 10, 11, 'Austin', 'Ball', 'Vidarte', '3', 'Comembo, Makati', 'austin@student', '09123450967'),
(24, 60, 10, 11, 'Cody', 'Can', 'Gordon', '3', 'Cailles, Bangkal', 'cody@student', '09058905656'),
(25, 61, 10, 11, 'Kevin', 'Diaz', 'Young', '3', 'Makati, Metro Manila', 'kevin@student', '09307864509'),
(26, 62, 10, 11, 'Darilin', 'Casey', 'Galvez', '3', 'Makati, Metro Manila', 'darilin@student', '09275640967'),
(27, 63, 10, 12, 'Troy', 'Heit', 'Jean', '3', 'Macabulos, Bangkal', 'troy@student', '09275670978'),
(28, 64, 10, 12, 'James', 'Seraphe', 'Legaspi', '3', 'Malvar, Bangkal', 'james@student', '09055674545'),
(29, 65, 10, 12, 'Godoel', 'Zaki', 'Refuerzo', '3', 'Vito Cruz, Manila', 'godoel@student', '09275648787'),
(30, 66, 10, 12, 'Renee', 'Ville', 'Obligar', '3', 'Macabulos, Bangkal', 'renee@student', '09156470956'),
(31, 67, 10, 12, 'Elsha', 'Lil', 'Sibulo', '3', 'Malvar, Bangkal', 'elsha@student', '09554567687'),
(32, 68, 10, 12, 'Daniel', 'Chab', 'Canedo', '3', 'Pembo, Makati', 'daniel@student', '09208905656'),
(33, 69, 10, 12, 'Jacob', 'Munar', 'Gomez', '3', 'Cabrera, Pasay', 'jacob@student', '09303356890'),
(35, 71, 10, 12, 'Emily', 'Rose', 'Heart', '3', 'Cailles, Bangkal', 'emily@student', '09220985655'),
(36, 72, 10, 12, 'Lauren', 'Paris', 'Thorton', '3', 'Macabulos, Bangkal', 'lauren@student', '09065667878'),
(37, 73, 10, 12, 'Krizia', 'Macab', 'Tandoc', '3', 'Comembo, Makati', 'krizia@student', '09125675656'),
(38, 74, 10, 13, 'Brad', 'Zian', 'Brocolli', '3', 'Makati, Metro Manila', 'brad@student', '09067895555'),
(39, 75, 10, 13, 'Justin', 'Bog', 'Cruzat', '3', 'Vito Cruz, Manila', 'justin@student', '09557890099'),
(40, 76, 10, 13, 'Buena', 'Boni', 'Abogadie', '3', 'Cabrera, Pasay', 'buena@student', '09267789056'),
(41, 77, 10, 13, 'Jose', 'Mari', 'Chan', '3', 'Makati, Metro Manila', 'jose@student', '09207890867'),
(42, 78, 10, 13, 'Gigi', 'Zone', 'Hadid', '3', 'Makati, Metro Manila', 'gigi@student', '09064567809'),
(43, 79, 10, 13, 'Jobie', 'Dela', 'Cruz', '3', 'Vito Cruz, Manila', 'jobie@student', '09123456767'),
(44, 80, 10, 13, 'Erika', 'Zee', 'Salvador', '3', 'Makati, Metro Manila', 'erika@student', '0975670999'),
(45, 81, 10, 13, 'Dianna', 'Marie', 'Agron', '3', 'Vito Cruz, Manila', 'dianna@student', '09063422870'),
(46, 82, 10, 13, 'Rachel', 'Nicole', 'Evans', '3', 'Vito Cruz, Manila', 'rnicole@student', '09228567435'),
(47, 83, 10, 13, 'Alice', 'Casino', 'Morales', '3', 'Malvar, Bangkal', 'alice@student', '09123456786'),
(48, 84, 10, 14, 'Angel', 'Gomez', 'Locsin', '3', 'Cailles, Bangkal', 'angel@student', '09123456767'),
(49, 85, 10, 14, 'Alexandra', 'Marie', 'Diaz', '3', 'Makati, Metro Manila', 'alexandra@student', '09254567878'),
(50, 86, 10, 14, 'Marc', 'Adrian', 'Jimenez', '3', 'Evangelista, Pasay', 'marc@student', '09054675656'),
(51, 87, 10, 14, 'Apple', 'Mijia', 'Sekino', '3', 'Comembo, Makati', 'apple@student', '09175670967'),
(52, 88, 10, 14, 'Abbie', 'Rei', 'Acerda', '3', 'Malvar, Bangkal', 'abbie@student', '09556789809'),
(53, 89, 10, 14, 'Andy', 'Nomer', 'Uzon', '3', 'Macabulos, Bangkal', 'andy@student', '09154563434'),
(54, 90, 10, 14, 'Audrey', 'Mario', 'Samia', '3', 'Macabulos, Bangkal', 'audrey@student', '09224565555'),
(55, 91, 10, 14, 'Ariel', 'Lao', 'Lazo', '3', 'Cabrera, Pasay', 'ariel@student', '09234456787'),
(56, 92, 10, 14, 'Ann', 'Marie', 'Cunanan', '3', 'Cabrera, Pasay', 'ann@student', '09234448721'),
(57, 93, 10, 14, 'Edward', 'Coco', 'Mojito', '3', 'Macabulos, Bangkal', 'edward@student', '09123449008');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `teacher_fname` varchar(20) NOT NULL,
  `teacher_mname` varchar(20) NOT NULL,
  `teacher_lname` varchar(20) NOT NULL,
  `teacher_district` varchar(10) NOT NULL,
  `teacher_address` varchar(50) NOT NULL,
  `teacher_email` varchar(20) NOT NULL,
  `teacher_contact` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `user_id`, `school_id`, `section_id`, `teacher_fname`, `teacher_mname`, `teacher_lname`, `teacher_district`, `teacher_address`, `teacher_email`, `teacher_contact`) VALUES
(4, 31, 10, 10, 'Felicita', 'Makisig', 'Delos Santos', '3', 'Bangkal, Makati', 'felicita@teacher', '09123547890'),
(5, 32, 10, 11, 'Bell', 'Manuel', 'Adriano', '3', 'Bangkal, Makati', 'bell@teacher', '6450923'),
(6, 33, 10, 12, 'Adrian', 'Zulueta', 'Santos', '3', 'Bangkal, Makati', 'adrian@teacher', '6758907'),
(7, 34, 10, 13, 'Denise', 'Cruz', 'Ocampo', '3', 'Park Avenue, Pasay City', 'denise@teacher', '5460192'),
(8, 35, 10, 14, 'Carlos', 'Lapira', 'Ruiz', '3', 'Evangelista, Pasay', 'carlos@teacher', '7589273'),
(9, 36, 10, 15, 'Joshua', 'Francia', 'Rodriguez', '3', 'Evangelista, Pasay', 'joshua@teacher', '3459340'),
(10, 37, 11, 16, 'Gabrielle', 'Rael', 'Mandia', '3', 'Malvar, Bangkal', 'gabrielle@teacher', '5796042'),
(11, 38, 11, 17, 'Jane', 'Pura', 'Cuesta', '3', 'Evangelista, Pasay', 'jane@teacher', '7492040'),
(12, 39, 11, 18, 'Miguel', 'Seo', 'Flores', '3', 'Vito Cruz, Manila', 'miguel@teacher', '4592032'),
(13, 40, 11, 19, 'Oscar', 'Yuzon', 'Villaran', '3', 'Macabulos, Bangkal', 'oscar@teacher', '5468290'),
(14, 41, 11, 20, 'Jillian', 'Batoon', 'Garcia', '3', 'Makati, Metro Manila', 'jillian@teacher', '7480273'),
(15, 42, 11, 21, 'Kyle', 'Legaspi', 'Sacupayo', '3', 'Evangelista, Pasay', 'kyle@teacher', '6380889');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_username` varchar(20) NOT NULL,
  `user_password` varchar(20) NOT NULL,
  `user_position` varchar(20) NOT NULL,
  `school_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_username`, `user_password`, `user_position`, `school_id`, `section_id`) VALUES
(1, 'district', 'pass', 'district', 0, 0),
(21, 'mainprincipal', 'pass', 'Principal', 10, 0),
(22, '2principal', 'pass', 'Principal', 11, 0),
(23, 'mainregistrar', 'pass', 'Registrar', 10, 0),
(24, '2registrar', 'pass', 'Registrar', 11, 0),
(26, 'mainguidance', 'pass', 'Guidance', 10, 0),
(30, '2guidance', 'pass', 'Guidance', 11, 0),
(31, 'felicitateacher', 'pass', 'Teacher', 10, 0),
(32, 'bellteacher', 'pass', 'Teacher', 10, 0),
(33, 'adrianteacher', 'pass', 'Teacher', 10, 0),
(34, 'deniseteacher', 'pass', 'Teacher', 10, 0),
(35, 'carlosteacher', 'pass', 'Teacher', 10, 0),
(36, 'joshuateaher', 'pass', 'Teacher', 10, 0),
(37, 'gabrielleteacher', 'pass', 'Teacher', 11, 0),
(38, 'janeteacher', 'pass', 'Teacher', 11, 0),
(39, 'miguelteacher', 'pass', 'Teacher', 11, 0),
(40, 'oscarteacher', 'pass', 'Teacher', 11, 0),
(41, 'jillianteacher', 'pass', 'Teacher', 11, 0),
(42, 'kyleteacher', 'pass', 'Teacher', 11, 0),
(43, 'nathanstudent', 'pass', 'Student', 10, 0),
(44, 'samanthastudent', 'pass', 'Student', 10, 0),
(45, 'patriciastudent', 'pass', 'Student', 10, 0),
(46, 'stephstudent', 'pass', 'Student', 10, 0),
(47, 'aikastudent', 'pass', 'Student', 10, 0),
(48, 'marvinstudent', 'pass', 'Student', 10, 0),
(49, 'francinestudent', 'pass', 'Student', 10, 0),
(50, 'charmainestudent', 'pass', 'Student', 10, 0),
(51, 'frankstudent', 'pass', 'Student', 10, 0),
(52, 'adamstudent', 'pass', 'Student', 10, 0),
(53, 'sherinestudent', 'pass', 'Student', 10, 0),
(54, 'darrelstudent', 'pass', 'Student', 10, 0),
(55, 'empressstudent', 'pass', 'Student', 10, 0),
(56, 'adrianstudent', 'pass', 'Student', 10, 0),
(57, 'zachstudent', 'pass', 'Student', 10, 0),
(58, 'marizstudent', 'pass', 'Student', 10, 0),
(59, 'austinstudent', 'pass', 'Student', 10, 0),
(60, 'codystudent', 'pass', 'Student', 10, 0),
(61, 'kevinstudent', 'pass', 'Student', 10, 0),
(62, 'darilinstudent', 'pass', 'Student', 10, 0),
(63, 'troystudent', 'pass', 'Student', 10, 0),
(64, 'jamesstudent', 'pass', 'Student', 10, 0),
(65, 'godoelstudent', 'pass', 'Student', 10, 0),
(66, 'reneestudent', 'pass', 'Student', 10, 0),
(67, 'elshastudent', 'pass', 'Student', 10, 0),
(68, 'danielstudent', 'pass', 'Student', 10, 0),
(69, 'jacobstudent', 'pass', 'Student', 10, 0),
(70, 'jacobstudent', 'pass', 'Student', 10, 0),
(71, 'emilystudent', 'pass', 'Student', 10, 0),
(72, 'laurenstudent', 'pass', 'Student', 10, 0),
(73, 'kriziastudent', 'pass', 'Student', 10, 0),
(74, 'bradstudent', 'pass', 'Student', 10, 0),
(75, 'justinstudent', 'pass', 'Student', 10, 0),
(76, 'buenastudent', 'pass', 'Student', 10, 0),
(77, 'josestudent', 'pass', 'Student', 10, 0),
(78, 'gigistudent', 'pass', 'Student', 10, 0),
(79, 'jobiestudent', 'pass', 'Student', 10, 0),
(80, 'erikastudent', 'pass', 'Student', 10, 0),
(81, 'dmarie', 'password', 'Student', 10, 0),
(82, 'rnicole', 'ilovefinn', 'Student', 10, 0),
(83, 'alicestudent', 'pass', 'Student', 10, 0),
(84, 'angelstudent', 'pass', 'Student', 10, 0),
(85, 'alexandrastudent', 'pass', 'Student', 10, 0),
(86, 'marcstudent', 'pass', 'Student', 10, 0),
(87, 'applestudent', 'pass', 'Student', 10, 0),
(88, 'abbiestudent', 'pass', 'Student', 10, 0),
(89, 'andystudent', 'pass', 'Student', 10, 0),
(90, 'audreystudent', 'pass', 'Student', 10, 0),
(91, 'arielstudent', 'pass', 'Student', 10, 0),
(92, 'annstudent', 'pass', 'Student', 10, 0),
(93, 'edwardstudent', 'pass', 'Student', 10, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `guidance`
--
ALTER TABLE `guidance`
  ADD PRIMARY KEY (`guidance_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`);

--
-- Indexes for table `mdl_quiz_grades`
--
ALTER TABLE `mdl_quiz_grades`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `principal`
--
ALTER TABLE `principal`
  ADD PRIMARY KEY (`principal_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`);

--
-- Indexes for table `registrar`
--
ALTER TABLE `registrar`
  ADD PRIMARY KEY (`registrar_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`school_id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`section_id`),
  ADD KEY `school_id` (`school_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `section_id` (`section_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `section_id` (`section_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `section_id` (`section_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `guidance`
--
ALTER TABLE `guidance`
  MODIFY `guidance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `principal`
--
ALTER TABLE `principal`
  MODIFY `principal_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `registrar`
--
ALTER TABLE `registrar`
  MODIFY `registrar_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `school`
--
ALTER TABLE `school`
  MODIFY `school_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `guidance`
--
ALTER TABLE `guidance`
  ADD CONSTRAINT `guidance_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `principal`
--
ALTER TABLE `principal`
  ADD CONSTRAINT `principal_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);

--
-- Constraints for table `registrar`
--
ALTER TABLE `registrar`
  ADD CONSTRAINT `registrar_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
