<?php

class Student_Result_Model extends CI_Model
{
	function __construct()
	{
		parent:: __construct();
	}

	function get_exam_details($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	
}