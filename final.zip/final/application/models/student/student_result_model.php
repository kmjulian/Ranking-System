<?php

class Student_Result_Model extends CI_Model
{
	function __construct()
	{
		parent:: __construct();
	}

	function get_exam_details($userid)
	{

		$this->db->select('student_id'); // select student id 
        $this->db->where('user_id', $userid); //nagccompare ako dito. $userid = kung anong user_id nung naka login tas yung user_id naman = siya sa user_id nung duon sa table nung student. 
        $query = $this->db->get('student'); //get from student table
        $id = $query->result(); //nilagay sa $id yung result
        $schlid = array(); // gumawa array
        foreach($id as $row){
            $schlid = array( 
                'schlid' => $row->student_id  //nilagay ko yung result dito sa array na to which is mga student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax'); //ayan sinelect ko na yung mga laman sa mdl_grade_grades
	    $this->db->from('mdl_grade_grades'); // from mdl_grade_grades table
	    $this->db->where('userid', $schlid['schlid']); // where userid duon sa mdl_grade_grades == sa mga data nung array. 
	    $query = $this->db->get();
	    return $query->result_array();
	}
	
}