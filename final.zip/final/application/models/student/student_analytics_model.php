<?php

class student_analytics_model extends CI_Model
{
	function __construct()
	{
		parent:: __construct();
	}

	function get_exam_details1($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 6);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details2($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 7);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details3($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 11);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details4($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 17);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details5($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 21);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details6($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 25);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details7($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 29);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details8($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 33);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details9($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 37);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details10($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 42);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details11($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 53);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details12($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 56);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details13($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 59);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details14($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 63);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details15($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 67);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details16($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 69);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details17($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 73);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details18($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 77);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details19($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 81);
	    $query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details20($userid)
	{

		$this->db->select('student_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('student');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }
        
		$this->db->select('id, itemid, userid, rawgrade, rawgrademax');
	    $this->db->from('mdl_grade_grades');
	    $this->db->where('userid', $schlid['schlid']);
	    $this->db->where('itemid', 85);
	    $query = $this->db->get();
	    return $query->result_array();
	}
}