<?php 

class View_School_User_Model extends CI_Model
{
	function __construct()
    {
        parent:: __construct();
    }

    function select_accounts($id)
	{	
		// $this->db->select('school_id');
		// $this->db->where('user_id', $userid);
  //       $query = $this->db->get('registrar');
  //       $id = $query->result();
  //       $schlid = array();
  //       foreach($id as $row){
  //           $schlid = array(
  //               'schlid' => $row->school_id
  //           );
  //       }

  //       $sid =  $schlid['schlid'];
		$this->db->select('user_id, user_username, user_position, school_id');
		$this->db->from('user');
		$this->db->where('school_id', $id);
		$query = $this->db->get();
		return $query->result_array();
	}

}