<?php
/**
* 
*/
class view_student_analytics_model extends CI_Model
{
	
	function __construct()
	{
		parent:: __construct();
	}    
	function grd2_I_1($userid)//filipino 1st quarter
	{

		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('principal');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}

		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}

	$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}

		$this->db->SELECT('AVG(rawgrade) as total');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_II_2($userid)//filipino 1st quarter
	{

		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('principal');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}

		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}

	$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}

		$this->db->SELECT('AVG(rawgrade) as total');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd3_I_1($userid)//filipino 1st quarter
	{

		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('principal');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}

		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}

	$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}

		$this->db->SELECT('AVG(rawgrade) as total');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$query = $this->db->GET();
		return $query->result_array();
	}
function grd3_II_2($userid)//filipino 1st quarter
	{

		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('principal');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}

		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}

	$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}

		$this->db->SELECT('AVG(rawgrade) as total');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd4_I_1($userid)//filipino 1st quarter
	{

		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('principal');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}

		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}

	$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}

		$this->db->SELECT('AVG(rawgrade) as total');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd4_II_2($userid)//filipino 1st quarter
	{

		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('principal');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}

		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}

	$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}

		$this->db->SELECT('AVG(rawgrade) as total');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$query = $this->db->GET();
		return $query->result_array();
	}


/*
	function grd2_IJuan_1($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_2($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_3($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_4($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_5($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_6($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_7($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_8($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_9($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_10($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_11($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_12($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_13($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_14($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_15($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_16($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_17($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_18($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_19($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_20($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
   	function grd2_IJuan_21($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_22($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_23($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_24($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_25($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_26($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_27($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_28($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_29($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_30($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_31($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_32($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_33($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_34($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_35($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_36($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_37($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_38($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_39($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_40($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_41($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_42($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_43($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_44($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_45($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_46($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_47($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_48($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_49($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_50($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_51($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_52($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_53($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_54($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_55($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_56($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_57($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_58($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_59($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_60($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_61($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_62($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_63($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_64($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_65($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_66($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_67($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_68($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_69($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_70($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_71($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_72($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_73($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_74($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_75($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_76($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_77($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_78($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_79($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_80($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_81($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_82($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_83($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_84($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_85($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_86($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_87($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_88($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_89($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_90($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_91($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_92($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_93($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_94($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_95($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_96($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_97($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_98($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_99($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_100($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_101($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_102($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_103($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_104($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_105($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_106($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_107($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_108($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_109($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_110($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_111($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_112($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_113($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_114($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_115($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_116($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_117($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_118($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_119($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_120($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_121($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_122($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_123($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_124($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_125($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_126($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_127($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_128($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_129($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_130($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_131($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_132($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_133($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_134($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_135($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_136($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_137($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_138($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_139($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_140($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
		function grd2_IJuan_141($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_142($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_143($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_144($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_145($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_146($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_147($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_148($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_149($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_150($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_151($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_152($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_153($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_154($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_155($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_156($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_157($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_158($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_159($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_160($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}

			function grd2_IJuan_161($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_162($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_163($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_164($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_165($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_166($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_167($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_168($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_169($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_170($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_171($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_172($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_173($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_174($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_175($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_176($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_177($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_178($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_179($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_180($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}

			function grd2_IJuan_181($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_182($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_183($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_184($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_185($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_186($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_187($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_188($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_189($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_190($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_191($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_192($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_193($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_194($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_195($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_196($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_197($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_198($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_199($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_200($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();	
		return $query->result_array();
	}  

	function grd2_IItimoteo_1($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IItimoteo_2($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IItimoteo_3($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IItimoteo4($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IItimoteo_5($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IItimoteo_6($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IItimoteo_7($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IItimoteo_8($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IItimoteo_9($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IItimoteo_10($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IItimoteo_11($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IItimoteo_12($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IItimoteo_13($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IItimoteo_14($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IItimoteo_15($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IItimoteo_16($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IItimoteoan_17($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_18($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_19($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_20($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
   	function grd2_IJuan_21($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_22($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_23($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_24($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_25($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_26($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_27($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_28($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_29($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_30($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_31($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_32($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_33($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_34($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_35($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_36($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_37($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_38($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_39($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_40($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(1,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_41($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_42($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_43($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_44($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_45($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_46($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_47($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_48($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_49($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_50($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_51($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_52($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_53($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_54($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_55($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_56($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_57($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_58($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_59($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_60($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(2,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_61($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_62($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_63($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_64($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_65($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_66($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_67($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_68($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_69($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_70($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_71($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_72($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_73($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_74($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_75($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_76($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_77($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_78($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_79($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_80($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(3,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_81($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_82($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_83($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_84($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_85($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_86($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_87($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_88($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_89($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_90($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_91($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_92($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_93($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_94($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_95($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_96($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_97($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_98($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_99($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_100($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(4,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_101($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_102($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_103($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_104($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_105($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_106($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_107($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_108($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_109($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_110($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_111($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_112($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_113($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_114($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_115($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_116($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_117($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_118($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_119($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_120($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(5,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_121($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_122($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_123($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_124($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_125($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_126($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_127($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_128($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_129($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_130($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_131($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_132($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_133($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_134($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_135($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_136($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_137($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_138($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_139($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_140($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(6,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
		function grd2_IJuan_141($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_142($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_143($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_144($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_145($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_146($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_147($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_148($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_149($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_150($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_151($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_152($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_153($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_154($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_155($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_156($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_157($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_158($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_159($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_160($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(7,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}

			function grd2_IJuan_161($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_162($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_163($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_164($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_165($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_166($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_167($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_168($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_169($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_170($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_171($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_172($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_173($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_174($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_175($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_176($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_177($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_178($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_179($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_180($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(8,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}

			function grd2_IJuan_181($userid)//filipino 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_182($userid)//filipino 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_183($userid)//filipino 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_184($userid)//filipino 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_185($userid)//English 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_186($userid)//English 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_187($userid)//English 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_188($userid)//English 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade, id');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_189($userid)//math 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_190($userid)//math 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_191($userid)//math 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_192($userid)//math 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_193($userid)//ap 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_194($userid)//ap 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_195($userid)//ap 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_196($userid)//ap 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_197($userid)//sci 1st quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_198($userid)//sci 2nd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}

	function grd2_IJuan_199($userid)//sci 3rd quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function grd2_IJuan_200($userid)//sci 4th quarter
	{
		$this->db->SELECT('school_id');
		$this->db->WHERE('user_id', $userid);
		$query = $this->db->GET('guidance');
		$id = $query->result();
		$schlid = array();
		foreach ($id as $value) {
			$schlid = array(
				'schlid' =>$value->school_id
			);
		}
	
		$this->db->SELECT('*');
		$this->db->WHERE('school_id', $schlid['schlid']);
		$this->db->LIMIT(1);
		$query = $this->db->GET('section');
		$id2 = $query->result();
		$secid1 = array();
		foreach ($id2 as $value2) {
			$secid1 = array(
				'secid1' => $value2->section_id
			);
		}
		$this->db->SELECT('student_id');
		$this->db->WHERE('section_id', $secid1['secid1']);	
		$this->db->LIMIT(9,1);
		$query = $this->db->GET('student');
		$id3 = $query->result();
		$studid = array();
		foreach ($id3 as $value3) {
			$studid = array(
				'studid' => $value3->student_id
			);
		}
		$this->db->SELECT('rawgrade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->WHERE('userid', $studid['studid']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();	
		return $query->result_array();
	}

}

*/
}