<?php

class View_District_Users_Model extends CI_Model
{
	public function __construct()
	{
		parent:: __construct();
	}

	function select_accounts()
	{
		$this->db->select('u.user_id, u.user_username, u.user_position, u.school_id');
		$this->db->from('user as u');
		$query = $this->db->get();
		return $query->result_array();
	}
}

