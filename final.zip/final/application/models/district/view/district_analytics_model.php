<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
/**
* 
*/
class district_analytics_model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}
	function get_school_grade1()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade2()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade3()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade4()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade5()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade6()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade7()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade8()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade9()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade10()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade11()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade12()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade13()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade14()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade15()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade16()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade17()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade18()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade19()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade20()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 10);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade21()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 6);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade22()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 7);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade23()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 11);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade24()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 17);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade25()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 21);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade26()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 25);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade27()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 29);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade28()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 33);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade29()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 37);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade30()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 42);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade31()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 53);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade32()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 56);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade33()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 59);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade34()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 63);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade35()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 67);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade36()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 69);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade37()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 73);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade38()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 77);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade39()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 81);
		$query = $this->db->GET();
		return $query->result_array();
	}
	function get_school_grade40()
	{
		$this->db->SELECT('school_id, student_id');
		$this->db->WHERE('school_id', 11);
		$query = $this->db->GET('student');
		$id = $query->result();
		$schlid1 = array();
		foreach ($id as $key) {
			$schlid1 = array(
				'schlid1' => $key->school_id
				);
		}
		$this->db->SELECT('AVG(rawgrade) as t_grade, AVG(rawgrademax) as max_grade');
		$this->db->FROM('mdl_grade_grades');
		$this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
		$this->db->WHERE('school_id', $schlid1['schlid1']);
		$this->db->WHERE('itemid', 85);
		$query = $this->db->GET();
		return $query->result_array();
	}
}
