<?php 

class Assign_Teacher_Section_Model extends CI_Model
{

	function __construct()
    {
        parent:: __construct();
    }

	function get_teacher_name($userid)
	{
        $this->db->select('school_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('registrar');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->school_id
            );
        }


		$this->db  ->select("teacher_id, school_id, teacher_fname, teacher_mname, teacher_lname")
                    ->from('teacher')
                    ->where('school_id', $schlid['schlid']);
        $query = $this->db->get();
        return $query->result_array();
	}

    function get_section_name($userid)
    {
        $this->db->select('school_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('registrar');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->school_id
            );
        }

        $this->db  ->select("section_id,grade_level, school_id, section_name")
                    ->from('section')
                    ->where('school_id', $schlid['schlid']);
        $query = $this->db->get();
        return $query->result_array();
    }


	function insert_teacher_account($data)
	{
        $data = array(
            'teacher_id' => $teacher,
        );

        $this->db->insert('teacher', $data);
    }
    
    function update_teacher_section($data, $teacherid)
    { 
        $this->db   ->where('teacher_id', $teacherid)
                    ->update('teacher', $data);

    }

    function update_user_section($data, $teacherid)
    {
        $this->db ->where('user_id', $teacherid)
                  ->update('user', $data);
    }

}