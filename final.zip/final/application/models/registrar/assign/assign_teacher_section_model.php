<?php 

class Assign_Teacher_Section_Model extends CI_Model
{

	function __construct()
    {
        parent:: __construct();
    }

	function get_teacher_name()
	{
		$this->db  ->select("teacher_id, teacher_fname")
                    ->from('teacher');
        $query = $this->db->get();
        return $query->result_array();
	}

    function get_section_name()
    {
        $this->db  ->select("section_id, section_name")
                    ->from('section');
        $query = $this->db->get();
        return $query->result_array();
    }

	function insert_teacher_account($data)
	{
        $this->db->select_max('teacher')
		$this->db->insert('teacher_id', $data);
	}
}