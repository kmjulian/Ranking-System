<?php 

class Assign_Teacher_Section_Model extends CI_Model
{

	function __construct()
    {
        parent:: __construct();
    }

	function get_teacher_name()
	{
		$this->db  ->select("teacher_id, teacher_fname, teacher_mname, teacher_lname")
                    ->from('teacher');
        $query = $this->db->get();
        return $query->result_array();
	}

    function get_section_name()
    {
        $this->db  ->select("section_id, section_name")
                    ->from('section');
        $query = $this->db->get();
        return $query->result_array();
    }

	function insert_teacher_account($data)
	{
        $data = array(
            'teacher_id' => $teacher,
        );

        $this->db->insert('teacher', $data);
    }
    
    function update_teacher_section($data, $teacherid)
    { 
        $this->db   ->where('teacher_id', $teacherid)
                    ->update('teacher', $data);

    }

    function update_user_section($data, $teacherid)
    {
        $this->db ->where('user_id', $teacherid)
                  ->update('user', $data);
    }

}