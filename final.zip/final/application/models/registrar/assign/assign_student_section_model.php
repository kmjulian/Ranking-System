<?php 

class Assign_Student_Section_Model extends CI_Model
{

	function __construct()
    {
        parent:: __construct();
    }

	function get_student_name($userid)
	{
        $this->db->select('school_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('registrar');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->school_id
            );
        }

        

		$this->db  ->select("student_id, school_id, student_fname, student_mname , student_lname")
                    ->from('student')
                    ->where('school_id', $schlid['schlid']);
        $query = $this->db->get();
        return $query->result_array();
	}

    function get_section_name($userid)
    {
        $this->db->select('school_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('registrar');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->school_id
            );
        }

        $this->db  ->select("section_id, school_id, section_name")
                    ->from('section')
                    ->where('school_id', $schlid['schlid']);
        $query = $this->db->get();
        return $query->result_array();
    }


	function insert_student_account($data)
	{
		$data = array(
            'student_id' => $student,
        );

        $this->db->insert('student', $data);
	}

    function update_student_section($data, $studentid)
    {
        $this->db   ->where('student_id', $studentid)
                    ->update('student', $data);
    }

    function update_user_account($data, $sectionid)
    {
        $this->db ->where('user_id', $sectionid)
                  ->update('user', $data);
    }
}