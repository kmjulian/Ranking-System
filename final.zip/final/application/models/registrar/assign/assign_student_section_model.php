<?php 

class Assign_Student_Section_Model extends CI_Model
{

	function __construct()
    {
        parent:: __construct();
    }

	function get_student_name()
	{
		$this->db  ->select("student_id, student_fname, student_mname , student_lname")
                    ->from('student');
        $query = $this->db->get();
        return $query->result_array();
	}

    function get_section_name()
    {
        $this->db  ->select("section_id, section_name")
                    ->from('section');
        $query = $this->db->get();
        return $query->result_array();
    }


	function insert_student_account($data)
	{
		$data = array(
            'student_id' => $student,
        );

        $this->db->insert('student', $data);
	}

    function update_student_section($data, $studentid)
    {
        $this->db   ->where('student_id', $studentid)
                    ->update('student', $data);
    }

    function update_user_account($data, $sectionid)
    {
        $this->db ->where('user_id', $sectionid)
                  ->update('user', $data);
    }
}