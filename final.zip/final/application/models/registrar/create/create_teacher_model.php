<?php 

class Create_Teacher_Model extends CI_Model
{

    function __construct()
    {
        parent:: __construct();
    }

    function get_school_name()
    {
        $this->db   ->select("school_id, school_name")
                    ->from('school');
        $query = $this->db->get();
        return $query->result_array();
    }

    function insert_user_account($data, $userid)
    {
        $this->db->select('school_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('registrar');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->school_id
            );
        }

        $this->db->set('school_id', $schlid['schlid']);
        $this->db->insert('user', $data);
    }

    function insert_teacher_account($data, $userid)
    {
        $this->db->select_max('user_id');
        $query = $this->db->get('user');
        $id = $query->result();
        $ui = array();
        foreach($id as $row){
            $ui = array(
                'uid' => $row->user_id
            );
        }

        $this->db->select('school_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('registrar');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->school_id
            );
        }

        $this->db->set('school_id', $schlid['schlid']);
        $this->db->set('user_id', $ui['uid']);
        $query = $this->db->insert('teacher', $data);
        return $this->db->insert_id();
    }
}