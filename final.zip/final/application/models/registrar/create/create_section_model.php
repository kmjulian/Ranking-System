<?php 

class Create_Section_Model extends CI_Model
{

	function __construct()
    {
        parent:: __construct();
    }


	function insert_section_account($data, $userid)
	{
		$this->db->select('school_id');
		$this->db->where('user_id', $userid);
        $query = $this->db->get('registrar');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->school_id
            );
        }

        $this->db->set('school_id', $schlid['schlid']);
		$this->db->insert('section', $data);
	}

	
}