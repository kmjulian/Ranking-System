<?php 

class View_Student_Users_Model extends CI_Model
{
	function __construct()
    {
        parent:: __construct();
    }

    function select_accounts($id)
	{	
		// $this->db->select('school_id');
		// $this->db->where('user_id', $userid);
  //       $query = $this->db->get('registrar');
  //       $id = $query->result();
  //       $schlid = array();
  //       foreach($id as $row){
  //           $schlid = array(
  //               'schlid' => $row->school_id
  //           );
  //       }

  //       $sid =  $schlid['schlid'];
		$this->db->select('user_id, student_id, student_fname, student_mname, student_lname, student_contact, student_address, section_id');
		$this->db->from('student');
		$this->db->where('school_id', $id);
		$query = $this->db->get();
		return $query->result_array();
	}

}