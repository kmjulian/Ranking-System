<?php

class View_Section_Result_Model extends CI_Model
{
	function __construct()
	{
		parent:: __construct();
	}

	function get_student_result($userid, $Schoolid)
	{
		$this->db->select('school_id');
        $this->db->where('user_id', $userid);
        $this->db->where('school_id', $Schoolid);
        $query = $this->db->get('guidance');
        $gid = $query->result();
        $guidance = array();
        foreach($gid as $row){
            $guidance = array(
                'gschool_id' => $row->school_id
            );
        }

        $this->db->select('section_id');
        $this->db->where('school_id', $guidance['gschool_id']);
        $query = $this->db->get('section');
        $sectionid = $query->result();
        $secid = array();
        foreach($sectionid as $row){
            $secid = array(
                'section_id' => $row->section_id
            );
        }

        $this->db->select('user_id, school_id, section_id');
        $this->db->where('school_id', $guidance['gschool_id']);
        $this->db->where('section_id', $secid['section_id']);
        $query = $this->db->get('student');
        $sid = $query->result();
        $student = array();
        foreach($sid as $row){
            $student = array(
                'suser_id' => $row->user_id
            );
        }

        $this->db->select('id, rawgrade, userid, student_fname');
        $this->db->from('mdl_grade_grades');
        $this->db->join('student','student.student_id = mdl_grade_grades.userid','left');
        $this->db->where('mdl_grade_grades.userid', $student['suser_id']);   
        $query = $this->db->get();
        return $query->result_array();
      
	}
    
}