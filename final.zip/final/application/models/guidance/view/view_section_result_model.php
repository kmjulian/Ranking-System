<?php

class View_Section_Result_Model extends CI_Model
{
	function __construct()
	{
		parent:: __construct();
	}

	function get_student_result($userid, $Schoolid)
	{
		$this->db->select('school_id');
        $this->db->where('user_id', $userid);
        $this->db->where('school_id', $Schoolid);
        $query = $this->db->get('guidance');
        $gid = $query->result();
        $guidance = array();
        foreach($gid as $row){
            $guidance = array(
                'gschool_id' => $row->school_id
            );
        }

        $this->db->select('section_id, grade_level');
        $this->db->where('school_id', $guidance['gschool_id']);
        $query = $this->db->get('section');
        $sectionid = $query->result();
        $secid = array();
        foreach($sectionid as $row){
            $secid = array(
                'section_id' => $row->section_id
            );
        }

        $this->db->select('student_id, school_id, section_id');
        $this->db->where('school_id', $guidance['gschool_id']);
        $this->db->where('section_id', $secid['section_id']);
        $query = $this->db->get('student');
        $sid = $query->result();
        $student = array();
        foreach($sid as $row){
            $student = array(
                'suser_id' => $row->student_id
            );
        }

        

        $this->db->select('student_id, student_fname, student_lname, userid, id, itemid, rawgrade, rawgrademax, section_id');
       
        $this->db->from('mdl_grade_grades'); 
        $this->db->join('student','student.student_id = mdl_grade_grades.userid');
         $this->db->where('student.school_id', $guidance['gschool_id']);

        
        // $item = "itemid = '87' OR itemid = '92' OR itemid = '97' OR itemid = '102'" ;
        //$item = "itemid = '6' OR itemid = '28' OR itemid = '56' OR itemid = '69'" ;
        //$this->db->where($item);
        
        


        
        $query = $this->db->get();
        return $query->result_array();
      



	}




/*
    function get_filigrades($Schoolid, $userid) {

        $item = "itemid = '6'";

     $this->db->select('itemid, rawgrade, rawgrademax, section_id');
     $this->db->group_by('section_id');
     $this->db->from('mdl_grade_grades');
    $this->db->join('mdl_grade_grades','mdl_grade_grades.itemid = mdl_quiz.id + 1', 'left');
    $this->db->where('mdl_quiz.itemid',$item );

        
        $query = $this->db->get();
        return $query->result_array();
      

    }
  
    function get_school($Schoolid)
    {

      $this->db->select('school_id');
      $this->db->from('guidance');
      $this->db->where('school_id', $Schoolid);

      $query = $this->db->get();

      return $query->result_array();
    }

function get_section($school)
    {
      
      $this->db->select('section_id');
      $this->db->from('section');
      $this->db->where('school_id', $school);

      $query = $this->db->get();

      return $query->result_array();
    }

function get_students($section)
    {
      $this->db->select('user_id');
      $this->db->from('student');
      $this->db->where('section_id', $section);

      $query = $this->db->get();

      return $query->result_array();
    }

    function get_grades($students)
    {

      $this->db->select('userid');
      $this->db->from('mdl_grade_grades');
      $this->db->where('userid', $students);
      
      $query = $this->db->get();

      return $query->result_array();
  }
  function filigrade($grades)
  {
    $item = "id = '5' OR id = '28' OR id='55' OR id='86'";

    $this ->db -> select('id');
    $this ->db -> from('mdl_quiz');
    $this ->db -> where('id', $item);

$query = $this->db->get();    
return $query->result_array();

  }*/
    

}