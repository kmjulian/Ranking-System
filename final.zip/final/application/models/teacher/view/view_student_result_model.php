<?php

class View_Student_Result_Model extends CI_Model
{
	function __construct()
	{
		parent:: __construct();
	}

	function get_student_result($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $tid = $query->result();
        $teacher = array();
        foreach($tid as $row){
            $teacher = array(
                'tsection' => $row->section_id
            );
        }

       	$this->db->select('student_id', 'student_fname', 'student_mname', 'student_lname');
        $this->db->where('section_id', $teacher['tsection']);
        $querys = $this->db->get('student');
        $id = $querys->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->student_id
            );
        }

		$this->db->select('userid, id, itemid, rawgrade, rawgrademax, student_fname, student_mname, student_lname');
	    $this->db->from('mdl_grade_grades');
        $this->db->join('student','student.student_id = mdl_grade_grades.userid','left');
	    $this->db->where('student.section_id',$teacher['tsection']);
	    $query = $this->db->get();
	    return $query->result_array();
	}
    
}