<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

/**
* 
*/
class view_student_analytics_model extends CI_Model
{
	
	function __construct()
	{
		parent:: __construct();
	}
	function get_exam_details1($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 6);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details2($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 7);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details3($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 11);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details4($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 17);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details5($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 21);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details6($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 25);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details7($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 29);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details8($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 33);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details9($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 37);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details10($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 42);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details11($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 53);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details12($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 56);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details13($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 59);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details14($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 63);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details15($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 67);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details16($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 69);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details17($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 73);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details18($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 77);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details19($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 81);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details20($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->select('rawgrade, rawgrademax, student_fname');
	    $this->db->from('mdl_grade_grades');
	    $this->db->join('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->where('userid', $stud_id_data['stud_id_data']);
	    $this->db->where('itemid', 85);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details21($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 	6);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details22($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 7);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details23($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 11);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details24($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 17);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details25($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 21);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details26($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 25);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details27($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 29);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details28($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 33);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details29($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 37);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details30($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 42);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details31($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 53);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details32($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 56);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details33($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 59);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details34($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 63);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details35($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 67);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details36($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 69);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details37($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 73);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details38($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 77);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details39($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 81);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details40($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(1,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 85);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details41($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 6);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details42($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 7);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details43($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 11);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details44($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 17);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details45($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 21);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details46($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 25);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details47($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 29);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details48($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 33);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details49($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 37);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details50($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 42);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details51($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 53);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details52($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 56);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details53($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 59);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details54($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 63);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details55($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 67);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details56($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 69);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details57($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 73);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details58($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 77);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details59($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 81);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details60($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(2,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 85);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details61($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 6);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details62($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 7);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details63($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 11);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details64($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 17);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details65($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 21);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details66($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 25);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details67($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 29);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details68($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 33);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details69($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 37);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details70($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 42);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details71($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 53);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details72($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 56);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details73($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 59);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details74($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 63);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details75($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 67);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details76($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 69);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details77($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 73);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details78($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 77);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details79($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 81);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details80($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(3,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 85);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details81($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 7);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details82($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 7);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details83($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 11);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details84($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 17);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details85($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 21);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details86($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 25);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details87($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 29);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details88($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 33);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details89($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 37);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details90($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 42);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details91($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 53);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details92($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 56);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details93($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 59);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details94($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 63);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details95($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 67);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details96($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 69);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details97($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 73);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details98($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 77);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details99($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 81);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details100($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(4,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 85);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details101($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 6);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details102($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 7);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details103($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 11);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details104($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 17);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details105($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 21);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details106($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 25);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details107($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 29);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details108($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 33);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details109($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 37);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details110($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 42);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details111($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 53);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details112($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 56);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details113($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 59);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details114($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 63);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details115($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 67);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details116($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 69);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details117($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 73);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details118($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 77);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details119($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 81);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
		function get_exam_details120($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(5,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 85);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details121($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 6);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details122($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 7);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details123($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 11);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details124($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 17);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details125($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 21);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details126($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 25);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details127($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 29);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details128($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 33);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details129($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 37);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details130($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 42);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details131($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 53);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details132($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 56);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details133($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 59);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details134($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 63);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details135($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 67);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details136($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 69);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details137($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 73);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details138($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 77);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details139($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 81);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details140($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(6,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 85);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details141($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 6);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details142($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 7);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details143($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 11);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details144($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 17);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details145($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 21);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details146($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 25);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details147($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 29);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details148($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 33);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details149($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 37);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details150($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 42);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details151($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 53);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details152($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 56);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details153($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 59);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details154($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 63);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details155($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 67);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details156($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 69);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details157($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 73);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details158($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 77);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details159($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 81);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details160($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(7,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 85);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details161($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 6);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details162($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 7);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details163($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 11);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details164($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 17);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details165($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 21);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details166($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 25);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details167($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 29);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details168($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 33);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details169($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 37);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details170($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 42);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details171($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 53);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details172($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 56);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details173($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 59);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details174($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 63);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details175($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 67);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details176($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 69);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details177($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 73);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details178($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 77);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details179($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 81);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details180($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(8,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 85);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details181($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 6);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details182($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 7);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details183($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 11);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details184($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 17);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details185($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 21);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details186($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 25);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details187($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 29);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details188($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 33);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details189($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 37);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details190($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 42);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details191($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 53);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details192($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 56);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details193($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 59);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details194($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 63);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details195($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 67);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details196($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 69);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details197($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 73);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details198($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 77);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details199($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 81);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
	function get_exam_details200($userid)
	{
		$this->db->select('section_id');
        $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $teach_id = array();
        foreach($id as $row){
            $teach_id = array(
                'teach_id' => $row->section_id
            );
        }
        
		$this->db->select('student_id, section_id, user_id','student_fname');
	    $this->db->from('student');
	    $this->db->where('section_id', $teach_id['teach_id']);
	    $this->db->LIMIT(9,1);
	    $query = $this->db->get();
	    $stud_id_res = $query->result();
	    $stud_id_data = array();
	    foreach ($stud_id_res as $key) {
	    	$stud_id_data = array(
	    		'stud_id_data' => $key->student_id
	    	);
	    }

	    $this->db->SELECT('rawgrade, rawgrademax, student_fname');
	    $this->db->FROM('mdl_grade_grades');
	    $this->db->JOIN('student','student.student_id = mdl_grade_grades.userid');
	    $this->db->WHERE('userid', $stud_id_data['stud_id_data']);
	    $this->db->WHERE('itemid', 85);
	  	$query = $this->db->get();
	    return $query->result_array();
	}
}