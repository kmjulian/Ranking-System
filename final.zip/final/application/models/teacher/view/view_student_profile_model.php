<?php 

class View_Student_Profile_Model extends CI_Model
{
  function __construct()
    {
        parent:: __construct();
    }

  function select_accounts($userid)
  { 
    $this->db->select('section_id');
    $this->db->where('user_id', $userid);
        $query = $this->db->get('teacher');
        $id = $query->result();
        $schlid = array();
        foreach($id as $row){
            $schlid = array(
                'schlid' => $row->section_id
            );
        }

        $sid =  $schlid['schlid'];
    $this->db->select('*');
    $this->db->from('student');
    $this->db->where('section_id', $sid);
    $query = $this->db->get();
    return $query->result_array();
  }

}