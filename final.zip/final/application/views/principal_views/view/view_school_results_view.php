<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        View Result by Section
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">View Informations</a></li>
        <li class="active">View Student Profile</li>
      </ol>
    </section>
		<section class="content">
		      <div class="row">
		        <div class="col-xs-12"> 
				  <div class="box">
		            <!-- /.box-header -->
		            <div class="box-body">
		              <table id="example1" class="table table-bordered table-striped">
		              <thead>
		                    <tr>
		                      
		                      <th>Section Name</th>
		                      <th>Overall Score by Section</th>
		                      <th>Max Score</th>
		                      <th>Percentage</th>
		                    </tr>
                 	  </thead>
		              <tbody>
		              	<?php foreach($result as $row) { ?> 
		           		
		              		<tr>
		              			<td><?php 
		           				if($row['section_id'] == 10) {
		           					echo "Grade 2, Section 1 - Juan";
		           				}elseif($row['section_id'] == 11){
		           					echo "Grade 2, Section 2 - Timoteo";
		           				}elseif($row['section_id'] == 12){
		           					echo "Grade 3, Section 1 - Samuel";
		           				}elseif($row['section_id'] == 13){
		           					echo "Grade 3, Section 2 - Mateo";
		           				}elseif($row['section_id'] == 14){
		           					echo "Grade 4, Section 1 - Hosea";
		           				}elseif($row['section_id'] == 15){
		           					echo "Grade 4, Section 2 - Ezra";
		           				}elseif($row['section_id'] == 16){
		           					echo "Grade 2, Section 1 - Jonas";
		           				}elseif($row['section_id'] == 17){
		           					echo "Grade 2, Section 2 - Daniel";
		           				}elseif($row['section_id'] == 18){
		           					echo "Grade 3, Section 1 - Isaias";
		           				}elseif($row['section_id'] == 19){
		           					echo "Grade 3, Section 2 - Pedro";
		           				}elseif($row['section_id'] == 20){
		           					echo "Grade 4, Section 1 - Santiago";
		           				}elseif($row['section_id'] == 21){
		           					echo "Grade 4, Section 2 - Job";
		           				}
		           				?></td>	
		           				<!-- <?php foreach ($grades as $filigrade) { ?>	
		           				<td> <?php echo $filigrade->rawgrade;?>  </td>
		           				<?php }?> 
		           			-->
		              			<td><?=$row['AVG(rawgrade)']?></td>
		              			<td><?=$row['AVG(rawgrademax)']?></td>
		              			<td><?=$row['AVG(rawgrade)'] / $row['AVG(rawgrademax)'] * 100 . "%" ?></td>
		              			
		              		</tr>




































		           		<!--	<tr>
		           				<td><?=$row['student_fname'] . " " . $row['student_lname']?></td>
		           				<td><?php 
		           				if($row['section_id'] == 10) {
		           					echo "Grade 2, Section 1 - Juan";
		           				}elseif($row['section_id'] == 11){
		           					echo "Grade 2, Section 2 - Timoteo";
		           				}elseif($row['section_id'] == 12){
		           					echo "Grade 3, Section 1 - Samuel";
		           				}elseif($row['section_id'] == 13){
		           					echo "Grade 3, Section 2 - Mateo";
		           				}elseif($row['section_id'] == 14){
		           					echo "Grade 4, Section 1 - Hosea";
		           				}elseif($row['section_id'] == 15){
		           					echo "Grade 4, Section 2 - Ezra";
		           				}elseif($row['section_id'] == 16){
		           					echo "Grade 2, Section 1 - Jonas";
		           				}elseif($row['section_id'] == 17){
		           					echo "Grade 2, Section 2 - Daniel";
		           				}elseif($row['section_id'] == 18){
		           					echo "Grade 3, Section 1 - Isaias";
		           				}elseif($row['section_id'] == 19){
		           					echo "Grade 3, Section 2 - Pedro";
		           				}elseif($row['section_id'] == 20){
		           					echo "Grade 4, Section 1 - Santiago";
		           				}elseif($row['section_id'] == 21){
		           					echo "Grade 4, Section 2 - Job";
		           				}
		           				?></td>
		           				<td><?=$row['itemid']?></td>
		           				<td><?=$row['rawgrade']?></td>
		           				<td><?=$row['rawgrademax']?></td>
								
		           			</tr>
		           			-->
		           		<?php } ?>
		              </tbody>
	                  </table>
	           	 </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
</div>