<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 3
    </div>
    <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Ranking Studio</a>.</strong> All rights
    reserved.
  </footer>

 
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/dist/js/demo.js"></script>

<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/Flot/jquery.flot.js"></script>
<!-- FLOT RESIZE PLUGIN - allows the chart to redraw when the window is resized -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/Flot/jquery.flot.resize.js"></script>
<!-- FLOT PIE PLUGIN - also used to draw donut charts -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/Flot/jquery.flot.pie.js"></script>
<!-- FLOT CATEGORIES PLUGIN - Used to draw bar charts -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/Flot/jquery.flot.categories.js"></script>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : false,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<?php 
if($student_analytics1 > 0){
  foreach ($student_analytics1 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade1 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics2 > 0){
  foreach ($student_analytics2 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade2 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics3 > 0){
  foreach ($student_analytics3 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade3 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics4 > 0){
  foreach ($student_analytics4 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade4 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics5 > 0){
  foreach ($student_analytics5 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade5 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics6 > 0){
  foreach ($student_analytics6 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade6 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics7 > 0){
  foreach ($student_analytics7 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade7 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics8 > 0){
  foreach ($student_analytics8 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade8 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics9 > 0){
  foreach ($student_analytics9 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade9 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics10 > 0){
  foreach ($student_analytics10 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade10 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics11 > 0){
  foreach ($student_analytics11 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade11 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics12 > 0){
  foreach ($student_analytics12 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade12 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics13 > 0){
  foreach ($student_analytics13 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade13 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics14 > 0){
  foreach ($student_analytics14 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade14 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics15 > 0){
  foreach ($student_analytics15 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade15 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics16 > 0){
  foreach ($student_analytics16 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade16 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics17 > 0){
  foreach ($student_analytics17 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade17 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics18 > 0){
  foreach ($student_analytics18 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade18 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics19 > 0){
  foreach ($student_analytics19 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade19 = ($rawgrade * $rawgrademax);
  } 
}
if($student_analytics20 > 0){
  foreach ($student_analytics20 as $key => $value) {
   $rawgrade = $value['rawgrade'];
   $rawgrademax = $value['rawgrademax'];
   $grade20 = ($rawgrade * $rawgrademax);
  } 
}
 ?>
<script>
    $(function () {
    
     /* BAR CHART */
    var bar_data = {
      data : [['Filipino',<?=$grade1; ?>], ['English',<?=$grade2; ?>], ['Mathematics',<?=$grade3; ?>], ['Araling Panlipunan',<?=$grade4; ?>], ['Science',<?=$grade5;?>]],
      color: '#0457b9',
  //     tooltips: 
  // mode: 'label'
    }
    $.plot('#bar-chart', [bar_data], {
      grid  : {
        borderWidth: 1,
        borderColor: '#f3f3f3',
        tickColor  : '#f3f3f3'
      },
      series: {
        bars: {
          show    : true,
          barWidth: 0.7,
          align   : 'center'
        }
      },
      xaxis : {
        mode      : 'categories',
        tickLength: 0
      }
    })

    var bar_data2 = {
      data : [['Filipino', <?=$grade6; ?>], ['English', <?=$grade7; ?>], ['Mathematics', <?=$grade8; ?>], ['Araling Panlipunan',<?=$grade9; ?>], ['Science',<?=$grade10; ?>]],
      color: '#be0501'
    }
    $.plot('#bar-chart2', [bar_data2], {
      grid  : {
        borderWidth: 1,
        borderColor: '#f3f3f3',
        tickColor  : '#f3f3f3'
      },
      series: {
        bars: {
          show    : true,
          barWidth: 0.7,
          align   : 'center'
        }
      },
      xaxis : {
        mode      : 'categories',
        tickLength: 0
      }
    })

    var bar_data3 = {
      data : [['Filipino',<?=$grade11;?>], ['English',<?=$grade12;?>], ['Mathematics',<?=$grade13;?>], ['Araling Panlipunan',<?=$grade14;?>], ['Science',<?=$grade15;?>]],
      color: '#78b002'
    }
    $.plot('#bar-chart3', [bar_data3], {
      grid  : {
        borderWidth: 1,
        borderColor: '#f3f3f3',
        tickColor  : '#f3f3f3'
      },
      series: {
        bars: {
          show    : true,
          barWidth: 0.7,
          align   : 'center'
        }
      },
      xaxis : {
        mode      : 'categories',
        tickLength: 0
      }
    })

    var bar_data4 = {
      data : [['Filipino',<?=$grade16;?>], ['English',<?=$grade17;?>], ['Mathematics',<?=$grade18;?>], ['Araling Panlipunan',<?=$grade19;?>], ['Science',<?=$grade20;?>]],
      color: '#4c05a0'
    }
    $.plot('#bar-chart4', [bar_data4], {
      grid  : {
        borderWidth: 1,
        borderColor: '#f3f3f3',
        tickColor  : '#f3f3f3'
      },
      series: {
        bars: {
          show    : true,
          barWidth: 0.7,
          align   : 'center'
        }
      },
      xaxis : {
        mode      : 'categories',
        tickLength: 0
      }
    })
    /* END BAR CHART */
  })
  </script>
</body>
</html>
