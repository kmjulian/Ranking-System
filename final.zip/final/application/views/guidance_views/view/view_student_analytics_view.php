<script>
    <?php
foreach ($student_analytics1 as $key => $value) {
    $grd2_sec1 = $value['total'];
  }
   foreach ($student_analytics2 as $key => $value) {
    $grd2_sec2 = $value['total'];
  }
   foreach ($student_analytics3 as $key => $value) {
    $grd3_sec1 = $value['total'];
  }
   foreach ($student_analytics4 as $key => $value) {
    $grd3_sec2 = $value['total'];
  }
   foreach ($student_analytics5 as $key => $value) {
    $grd4_sec1 = $value['total'];
  }
   foreach ($student_analytics6 as $key => $value) {
    $grd4_sec2 = $value['total'];
  }
?>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
  animationEnabled: true,
  theme: "light2", // "light1", "light2", "dark1", "dark2"
  title:{
    text: "Student Analytics"
  },
  data: [{        
    type: "column",  
    showInLegend: true, 
    legendMarkerColor: "grey",
    legendText: "Guidance View",
    dataPoints: [      
      { y: <?php
            if ($grd2_sec1 > 0){
                echo $grd2_sec1;
            }else 
                echo 0;
       ?>, label: "Grade II, Section I" },
      { y: <?php
            if ($grd2_sec2 > 0){
                echo $grd2_sec2;
            }else 
                echo 0;?>,  label: "Grade II, Section II" },
      { y: <?php
            if ($grd3_sec1 > 0){
                echo $grd3_sec1;
            }else 
                echo 0;?>,  label: "Grade III, Section I" },
      { y: <?php
            if ($grd3_sec2 > 0){
                echo $grd3_sec2;
            }else 
                echo 0;?>,  label: "Grade III, Section II" },
      { y: <?php
            if ($grd4_sec1 > 0){
                echo $grd4_sec1;
            }else 
                echo 0;?>,  label: "Grade IV, Section I" },
      { y: <?php
            if ($grd4_sec1 > 0){
                echo $grd2_sec2;
            }else 
                echo 0;?>, label: "Grade IV, Section II" }
    ]
  }]
});
chart.render();

}
</script>
<div class="content-wrapper">
    <section class="content-header">
       <h1>
        Student Analytics
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">View Informations</a></li>
        <li class="active">View Student Analytics</li>
      </ol>
    </section>
    <section class="content">
      <!-- <div style="margin-top: 50px; margin-left: 118px;"> -->
       <!-- <div class="col-md-11" style="background-color: white;"> -->
            
       <div id="chartContainer" style="height: 370px; width: 100%;"></div>
      <!-- </div> -->
    <!-- </div> -->
    </section>
</div>

<?php 

// $user - session yung 

// $mdl_grade_grades 