<div class="content-wrapper">
  <section class="content-header">
      <h1>
        Student Analytics
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">View Informations</a></li>
        <li class="active">View Student Analytics</li>
      </ol>
    </section>
    <div align="center">
    <div class="row">
    <div class="col-md-6">
      <h4>1st Quarter</h4>
       <canvas id="mybarChart2"></canvas>
     </div>
     <div class="col-md-6">
      <h4>2nd Quarter</h4>
       <canvas id="mybarChart3"></canvas>
     </div>
   </div>
   <div class="row">
       <div class="col-md-6">

    <h4>3rd Quarter</h4>
       <canvas id="mybarChart4"></canvas>
     </div>
     <div class="col-md-6">
      <h4>4th Quarter</h4>
       <canvas id="mybarChart5"></canvas>
     </div>

  </div>
</div>
    </section>
</div>