<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 3
    </div>
    <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Ranking Studio</a>.</strong> All rights
    reserved.
  </footer>

 
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<!-- jQuery 3 -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/dist/js/demo.js"></script>

<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/chart.js/guidance chart/Chart.min.js"></script>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : false,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>

<script type="text/javascript">
  <?php
  if($grade1 > 0){
    foreach ($grade1 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total1 = $rawgrade * $rawgrademax;
    }
  }
    if($grade2 > 0){
    foreach ($grade2 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total2 = $rawgrade * $rawgrademax;
    }
  }
   if($grade3 > 0){
    foreach ($grade3 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total3 = $rawgrade * $rawgrademax;
    }
  }
  if($grade4 > 0){
    foreach ($grade4 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total4 = $rawgrade * $rawgrademax;
    }
  }
  if($grade5 > 0){
    foreach ($grade5 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total5 = $rawgrade * $rawgrademax;
    }
  }
    if($grade21 > 0){
    foreach ($grade21 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total21 = $rawgrade * $rawgrademax;
    }
  }
    if($grade22 > 0){
    foreach ($grade22 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total22 = $rawgrade * $rawgrademax;
    }
  }
    if($grade23 > 0){
    foreach ($grade23 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total23 = $rawgrade * $rawgrademax;
    }
  }
    if($grade24 > 0){
    foreach ($grade24 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total24 = $rawgrade * $rawgrademax;
    }
  }
    if($grade25 > 0){
    foreach ($grade25 as $key => $value){
      $fname2 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total25 = $rawgrade * $rawgrademax;
    }
  }
   if($grade41 > 0){
    foreach ($grade41 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total41 = $rawgrade * $rawgrademax;
    }
  }
     if($grade42 > 0){
    foreach ($grade42 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total42 = $rawgrade * $rawgrademax;
    }
  }
     if($grade43 > 0){
    foreach ($grade43 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total43 = $rawgrade * $rawgrademax;
    }
  }
     if($grade44 > 0){
    foreach ($grade44 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total44 = $rawgrade * $rawgrademax;
    }
  }
     if($grade45 > 0){
    foreach ($grade45 as $key => $value){
      $fname3 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total45 = $rawgrade * $rawgrademax;
    }
  }
     if($grade61 > 0){
    foreach ($grade51 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total61 = $rawgrade * $rawgrademax;
    }
  }
     if($grade62 > 0){
    foreach ($grade62 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total62 = $rawgrade * $rawgrademax;
    }
  }
     if($grade63 > 0){
    foreach ($grade63 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total63 = $rawgrade * $rawgrademax;
    }
  }
     if($grade64 > 0){
    foreach ($grade64 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total64 = $rawgrade * $rawgrademax;
    }
  }
     if($grade65 > 0){
    foreach ($grade65 as $key => $value){
      $fname4 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total65 = $rawgrade * $rawgrademax;
    }
  }
     if($grade81 > 0){
    foreach ($grade81 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total81 = $rawgrade * $rawgrademax;
    }
  }
    if($grade82 > 0){
    foreach ($grade82 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total82 = $rawgrade * $rawgrademax;
    }
  }
     if($grade83 > 0){
    foreach ($grade83 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total83 = $rawgrade * $rawgrademax;
    }
  }
    if($grade84 > 0){
    foreach ($grade84 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total84 = $rawgrade * $rawgrademax;
    }
  }
     if($grade85 > 0){
    foreach ($grade85 as $key => $value){
      $fname5 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total85= $rawgrade * $rawgrademax;
    }
  }

     if($grade101 > 0){
    foreach ($grade101 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total101= $rawgrade * $rawgrademax;
    }
  }
     if($grade102 > 0){
    foreach ($grade102 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total102= $rawgrade * $rawgrademax;
    }
  }
     if($grade103 > 0){
    foreach ($grade103 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total103= $rawgrade * $rawgrademax;
    }
  }
     if($grade104 > 0){
    foreach ($grade104 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total104= $rawgrade * $rawgrademax;
    }
  }
     if($grade105 > 0){
    foreach ($grade105 as $key => $value){
      $fname6 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total105= $rawgrade * $rawgrademax;
    }
  }
  if($grade121 > 0){
    foreach ($grade121 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];
      $total121 = $rawgrade * $rawgrademax;
    }
  }
  if($grade122 > 0){
    foreach ($grade122 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total122= $rawgrade * $rawgrademax;
    }
  }
  if($grade123 > 0){
    foreach ($grade123 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total123= $rawgrade * $rawgrademax;
    }
  }
  if($grade124 > 0){
    foreach ($grade124 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total124 = $rawgrade * $rawgrademax;
    }
  }
  if($grade125 > 0){
    foreach ($grade125 as $key => $value){
      $fname7 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total125 = $rawgrade * $rawgrademax;
    }
  }
if($grade141 > 0){
    foreach ($grade141 as $key => $value){
      $fname8 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total141 = $rawgrade * $rawgrademax;
    }
  }
  if($grade142 > 0){
    foreach ($grade142 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total142 = $rawgrade * $rawgrademax;
    }
  }
   if($grade143 > 0){
    foreach ($grade143 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total143 = $rawgrade * $rawgrademax;
    }
  }
   if($grade144 > 0){
    foreach ($grade144 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total144 = $rawgrade * $rawgrademax;
    }
  }
   if($grade145 > 0){
    foreach ($grade145 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total145 = $rawgrade * $rawgrademax;
    }
  }
   if($grade161 > 0){
    foreach ($grade161 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total161 = $rawgrade * $rawgrademax;
    }
  }
   if($grade162 > 0){
    foreach ($grade162 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total162 = $rawgrade * $rawgrademax;
    }
  }
   if($grade163 > 0){
    foreach ($grade163 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total163 = $rawgrade * $rawgrademax;
    }
  }
   if($grade164 > 0){
    foreach ($grade164 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total164 = $rawgrade * $rawgrademax;
    }
  }
   if($grade165 > 0){
    foreach ($grade165 as $key => $value){
      $fname9 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total165 = $rawgrade * $rawgrademax;
    }
  }
     if($grade181 > 0){
    foreach ($grade181 as $key => $value){
      $fname10 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total181 = $rawgrade * $rawgrademax;
    }
  }
      if($grade182 > 0){
    foreach ($grade182 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total182 = $rawgrade * $rawgrademax;
    }
  }
  if($grade183 > 0){
    foreach ($grade183 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total183 = $rawgrade * $rawgrademax;
    }
  }
  if($grade184 > 0){
    foreach ($grade184 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total184 = $rawgrade * $rawgrademax;
    }
  }
  if($grade185 > 0){
    foreach ($grade185 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total185 = $rawgrade * $rawgrademax;
    }
  }
 ?>
    var ctx2 = document.getElementById("mybarChart2");
      var mybarChart2 = new Chart(ctx2, {
        type: 'bar',
        data: {
          labels: ["Filipino", "English", "Mathematics", "Araling Panlipunan", "Science"],
          datasets: [{
            label: '<?=$fname;?>',
            backgroundColor: "#4F81BC",
            data: [<?=$total1;?>, <?=$total2;?>, <?=$total3;?>, <?=$total4;?>,<?=$total5;?>]
          }, {
            label: '<?=$fname2;?>',
            backgroundColor: "#C0504E",
            data: [<?=$total21;?>, <?=$total22;?>, <?=$total23;?>, <?=$total24;?>,<?=$total25;?>]
          },
          {
            label: '<?=$fname3;?>',
            backgroundColor: "#9BBB58",
             data: [<?=$total41;?>, <?=$total42;?>, <?=$total43;?>, <?=$total44;?>,<?=$total45;?>]
          },
          {
            label: '<?=$fname4;?>',
            backgroundColor: "#23BFAA",
             data: [<?=$total61;?>, <?=$total62;?>, <?=$total63;?>, <?=$total64;?>,<?=$total65;?>]
          },
          {
            label: '<?=$fname5;?>',
            backgroundColor: "#8064A1",
             data: [<?=$total81;?>, <?=$total82;?>, <?=$total83;?>, <?=$total84;?>,<?=$total85;?>]
          },
          {
             label: '<?=$fname6;?>',
            backgroundColor: "#4AACC5",
             data: [<?=$total101;?>, <?=$total102;?>, <?=$total103;?>, <?=$total104;?>,<?=$total105;?>]
          },
          {
           label: '<?=$fname7;?>',
            backgroundColor: "#F5923E",
              data: [<?=$total121;?>, <?=$total122;?>, <?=$total123;?>, <?=$total124;?>,<?=$total125;?>]
          },
          {
            label: '<?=$fname8;?>',
            backgroundColor: "#815E86",
             data: [<?=$total141;?>, <?=$total142;?>, <?=$total143;?>, <?=$total144;?>,<?=$total145;?>]
          },
          {
             label: '<?=$fname9;?>',
            backgroundColor: "#779F35",
             data: [<?=$total161;?>, <?=$total162;?>, <?=$total163;?>, <?=$total164;?>,<?=$total165;?>]
          },
          {
            label: '<?=$fname10;?>',
            backgroundColor: "#34558A",
             data: [<?=$total181;?>, <?=$total182;?>, <?=$total183;?>, <?=$total184;?>,<?=$total185;?>]
          }
          ]
        },

        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }]
          }
        }
      });
      <?php
      if($grade6 > 0){
    foreach ($grade6 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total6 = $rawgrade * $rawgrademax;
    }
  }
  if($grade7 > 0){
    foreach ($grade7 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total7 = $rawgrade * $rawgrademax;
    }
  }
  if($grade8 > 0){
    foreach ($grade8 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total8 = $rawgrade * $rawgrademax;
    }
  }
  if($grade9 > 0){
    foreach ($grade9 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total9 = $rawgrade * $rawgrademax;
    }
  }
  if($grade10 > 0){
    foreach ($grade10 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total10 = $rawgrade * $rawgrademax;
    }
  }
if($grade26 > 0){
    foreach ($grade26 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total26 = $rawgrade * $rawgrademax;
    }
  }
  if($grade27 > 0){
    foreach ($grade27 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total27 = $rawgrade * $rawgrademax;
    }
  }
  if($grade28 > 0){
    foreach ($grade28 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total28 = $rawgrade * $rawgrademax;
    }
  }
  if($grade29 > 0){
    foreach ($grade29 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total29 = $rawgrade * $rawgrademax;
    }
  }
  if($grade30 > 0){
    foreach ($grade30 as $key => $value){
      $fname2 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total30 = $rawgrade * $rawgrademax;
    }
  }
  if($grade46 > 0){
    foreach ($grade46 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total46 = $rawgrade * $rawgrademax;
    }
  }
  if($grade47 > 0){
    foreach ($grade47 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total47 = $rawgrade * $rawgrademax;
    }
  }

  if($grade48 > 0){
    foreach ($grade48 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total48= $rawgrade * $rawgrademax;
    }
  }

  if($grade49 > 0){
    foreach ($grade49 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total49 = $rawgrade * $rawgrademax;
    }
  }

  if($grade50 > 0){
    foreach ($grade50 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total50 = $rawgrade * $rawgrademax;
    }
  }
     if($grade66 > 0){
    foreach ($grade66 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total66 = $rawgrade * $rawgrademax;
    }
  }
     if($grade67 > 0){
    foreach ($grade67 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total67 = $rawgrade * $rawgrademax;
    }
  }
     if($grade68 > 0){
    foreach ($grade68 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total68= $rawgrade * $rawgrademax;
    }
  }
     if($grade69 > 0){
    foreach ($grade69 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total69 = $rawgrade * $rawgrademax;
    }
  }
     if($grade70 > 0){
    foreach ($grade70 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total70 = $rawgrade * $rawgrademax;
    }
  }
     if($grade86 > 0){
    foreach ($grade86 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total86 = $rawgrade * $rawgrademax;
    }
  }
     if($grade87 > 0){
    foreach ($grade87 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total87= $rawgrade * $rawgrademax;
    }
  }
     if($grade88 > 0){
    foreach ($grade88 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total88= $rawgrade * $rawgrademax;
    }
  }
     if($grade89 > 0){
    foreach ($grade89 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total89= $rawgrade * $rawgrademax;
    }
  }
     if($grade90 > 0){
    foreach ($grade90 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total90= $rawgrade * $rawgrademax;
    }
  }

     if($grade106 > 0){
    foreach ($grade106 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total106= $rawgrade * $rawgrademax;
    }
  }
     if($grade107 > 0){
    foreach ($grade107 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total107= $rawgrade * $rawgrademax;
    }
  }
     if($grade108 > 0){
    foreach ($grade108 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total108= $rawgrade * $rawgrademax;
    }
  }
     if($grade109 > 0){
    foreach ($grade109 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total109= $rawgrade * $rawgrademax;
    }
  }
     if($grade110 > 0){
    foreach ($grade110 as $key => $value){
      $fname6 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total110= $rawgrade * $rawgrademax;
    }
  }
  if($grade126 > 0){
    foreach ($grade126 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total126= $rawgrade * $rawgrademax;
    }
  }
  if($grade127 > 0){
    foreach ($grade127 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total127= $rawgrade * $rawgrademax;
    }
  }
  if($grade128 > 0){
    foreach ($grade128 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total128= $rawgrade * $rawgrademax;
    }
  }
  if($grade129 > 0){
    foreach ($grade129 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total129 = $rawgrade * $rawgrademax;
    }
  }
  if($grade130 > 0){
    foreach ($grade130 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total130 = $rawgrade * $rawgrademax;
    }
  }
  if($grade146 > 0){
    foreach ($grade146 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total146 = $rawgrade * $rawgrademax;
    }
  }
  if($grade147 > 0){
    foreach ($grade147 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total147 = $rawgrade * $rawgrademax;
    }
  }
   if($grade148 > 0){
    foreach ($grade148 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total148 = $rawgrade * $rawgrademax;
    }
  }
   if($grade149 > 0){
    foreach ($grade149 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total149 = $rawgrade * $rawgrademax;
    }
  }
   if($grade150 > 0){
    foreach ($grade150 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total150 = $rawgrade * $rawgrademax;
    }
  }
  if($grade166 > 0){
    foreach ($grade166 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total166 = $rawgrade * $rawgrademax;
    }
  }
   if($grade167 > 0){
    foreach ($grade167 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total167 = $rawgrade * $rawgrademax;
    }
  }
   if($grade168 > 0){
    foreach ($grade168 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total168 = $rawgrade * $rawgrademax;
    }
  }
   if($grade169 > 0){
    foreach ($grade169 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total169 = $rawgrade * $rawgrademax;
    }
  }
   if($grade170 > 0){
    foreach ($grade170 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total170 = $rawgrade * $rawgrademax;
    }
  }
   if($grade186 > 0){
    foreach ($grade186 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total186 = $rawgrade * $rawgrademax;
    }
  }
   if($grade187 > 0){
    foreach ($grade187 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total187 = $rawgrade * $rawgrademax;
    }
  }
   if($grade188 > 0){
    foreach ($grade188 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total188 = $rawgrade * $rawgrademax;
    }
  }
   if($grade189 > 0){
    foreach ($grade189 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total189 = $rawgrade * $rawgrademax;
    }
  }
   if($grade190 > 0){
    foreach ($grade190 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total190 = $rawgrade * $rawgrademax;
    }
  }
       ?>
       var ctx3 = document.getElementById("mybarChart3");
      var mybarChart3 = new Chart(ctx3, {
        type: 'bar',
        data: {
          labels: ["Filipino", "English", "Mathematics","Araling Panlipunan","Science"],
          datasets: [{
               label: '<?=$fname;?>',
            backgroundColor: "#4F81BC",
            data: [<?=$total6?>, <?=$total7?>, <?=$total8?>, <?=$total9?>,<?=$total10?>]
          }, {
            label: '<?=$fname2;?>',
            backgroundColor: "#C0504E",
            data: [<?=$total26?>, <?=$total27?>, <?=$total28?>, <?=$total29?>,<?=$total30?>]
          },
          {
            label: '<?=$fname3;?>',
           backgroundColor: "#9BBB58",
             data: [<?=$total46?>, <?=$total47?>, <?=$total48?>, <?=$total49?>,<?=$total50?>]
          },
          {
            label: '<?=$fname4;?>',
             backgroundColor: "#23BFAA",
             data: [<?=$total67?>, <?=$total67?>, <?=$total68?>, <?=$total69?>,<?=$total70?>]
          },
          {
             label: '<?=$fname5;?>',
           backgroundColor: "#8064A1",
             data: [<?=$total86?>, <?=$total87?>, <?=$total88?>, <?=$total89?>,<?=$total90?>]
          },
          {
            label: '<?=$fname6;?>',
            backgroundColor: "#4AACC5",
             data: [<?=$total106?>, <?=$total107?>, <?=$total108?>, <?=$total109?>,<?=$total110?>]
          },
          {
             label: '<?=$fname7;?>',
            backgroundColor: "#F5923E",
             data: [<?=$total126?>, <?=$total127?>, <?=$total128?>, <?=$total129?>,<?=$total130?>]
          },
          {
             label: '<?=$fname8;?>',
            backgroundColor: "#815E86",
             data: [<?=$total146?>, <?=$total147?>, <?=$total148?>, <?=$total149?>,<?=$total150?>]
          },
          {
           label: '<?=$fname9;?>',
             backgroundColor: "#779F35",
             data: [<?=$total166?>, <?=$total167?>, <?=$total168?>, <?=$total169?>,<?=$total170?>]
          },
          {
             label: '<?=$fname10;?>',
            backgroundColor: "#34558A",
              data: [<?=$total186?>, <?=$total187?>, <?=$total188?>, <?=$total189?>,<?=$total190?>]
          }
          ]
        },

        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }]
          }
        }
      });
      <?php 
        if($grade11 > 0){
    foreach ($grade11 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total11 = $rawgrade * $rawgrademax;
    }
  }
  if($grade12 > 0){
    foreach ($grade12 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total12 = $rawgrade * $rawgrademax;
    }
  }
  if($grade13 > 0){
    foreach ($grade13 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total13 = $rawgrade * $rawgrademax;
    }
  }
  if($grade14 > 0){
    foreach ($grade14 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total14 = $rawgrade * $rawgrademax;
    }
  }
  if($grade15 > 0){
    foreach ($grade15 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total15 = $rawgrade * $rawgrademax;
    }
  }
  if($grade31 > 0){
    foreach ($grade31 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total31 = $rawgrade * $rawgrademax;
    }
  }
   if($grade32 > 0){
    foreach ($grade32 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total32 = $rawgrade * $rawgrademax;
    }
  }
   if($grade33 > 0){
    foreach ($grade33 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total33 = $rawgrade * $rawgrademax;
    }
  }
   if($grade34 > 0){
    foreach ($grade34 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total34 = $rawgrade * $rawgrademax;
    }
  }
   if($grade35 > 0){
    foreach ($grade35 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total35 = $rawgrade * $rawgrademax;
    }
  }
  if($grade51 > 0){
    foreach ($grade51 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total51 = $rawgrade * $rawgrademax;
    }
  }
  if($grade52 > 0){
    foreach ($grade52 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total52 = $rawgrade * $rawgrademax;
    }
  }
  if($grade53 > 0){
    foreach ($grade53 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total53 = $rawgrade * $rawgrademax;
    }
  }
  if($grade54 > 0){
    foreach ($grade54 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total54 = $rawgrade * $rawgrademax;
    }
  }
  if($grade55 > 0){
    foreach ($grade55 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total55 = $rawgrade * $rawgrademax;
    }
  }
     if($grade71 > 0){
    foreach ($grade71 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total71 = $rawgrade * $rawgrademax;
    }
  }
     if($grade72 > 0){
    foreach ($grade72 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total72 = $rawgrade * $rawgrademax;
    }
  }
     if($grade73 > 0){
    foreach ($grade73 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total73 = $rawgrade * $rawgrademax;
    }
  }
     if($grade74 > 0){
    foreach ($grade74 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total74 = $rawgrade * $rawgrademax;
    }
  }
  if($grade75 > 0){
    foreach ($grade75 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total75 = $rawgrade * $rawgrademax;
    }
  }
       if($grade91 > 0){
    foreach ($grade91 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total91 = $rawgrade * $rawgrademax;
    }
  }
     if($grade92 > 0){
    foreach ($grade92 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total92= $rawgrade * $rawgrademax;
    }
  }
     if($grade93 > 0){
    foreach ($grade93 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total93= $rawgrade * $rawgrademax;
    }
  }
     if($grade94 > 0){
    foreach ($grade94 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total94= $rawgrade * $rawgrademax;
    }
  }
     if($grade95 > 0){
    foreach ($grade95 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total95= $rawgrade * $rawgrademax;
    }
  }
     if($grade111 > 0){
    foreach ($grade111 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total111 = $rawgrade * $rawgrademax;
    }
  }
     if($grade112 > 0){
    foreach ($grade112 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total112 = $rawgrade * $rawgrademax;
    }
  }
     if($grade113 > 0){
    foreach ($grade113 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total113 = $rawgrade * $rawgrademax;
    }
  }
     if($grade114 > 0){
    foreach ($grade114 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total114 = $rawgrade * $rawgrademax;
    }
  }
     if($grade115 > 0){
    foreach ($grade115 as $key => $value){
      $fname6 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total115 = $rawgrade * $rawgrademax;
    }
  } 
   if($grade131 > 0){
    foreach ($grade131 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total131= $rawgrade * $rawgrademax;
    }
  }
  if($grade132 > 0){
    foreach ($grade132 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total132= $rawgrade * $rawgrademax;
    }
  }
  if($grade133 > 0){
    foreach ($grade133 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total133= $rawgrade * $rawgrademax;
    }
  }
  if($grade134 > 0){
    foreach ($grade134 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total134 = $rawgrade * $rawgrademax;
    }
  }
  if($grade135 > 0){
    foreach ($grade135 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total135 = $rawgrade * $rawgrademax;
    }
  }
    if($grade151 > 0){
    foreach ($grade151 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total151 = $rawgrade * $rawgrademax;
    }
  }
  if($grade152 > 0){
    foreach ($grade152 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total152 = $rawgrade * $rawgrademax;
    }
  }
   if($grade153 > 0){
    foreach ($grade153 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total153 = $rawgrade * $rawgrademax;
    }
  }
   if($grade154 > 0){
    foreach ($grade154 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total154 = $rawgrade * $rawgrademax;
    }
  }
   if($grade155 > 0){
    foreach ($grade155 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total155 = $rawgrade * $rawgrademax;
    }
  }
    if($grade171 > 0){
    foreach ($grade171 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total171 = $rawgrade * $rawgrademax;
    }
  }
   if($grade172 > 0){
    foreach ($grade172 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total172 = $rawgrade * $rawgrademax;
    }
  }
   if($grade173 > 0){
    foreach ($grade173 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total173 = $rawgrade * $rawgrademax;
    }
  }
   if($grade174 > 0){
    foreach ($grade174 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total174 = $rawgrade * $rawgrademax;
    }
  }
   if($grade175 > 0){
    foreach ($grade175 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total175 = $rawgrade * $rawgrademax;
    }
  }
  if($grade191 > 0){
    foreach ($grade191 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total191 = $rawgrade * $rawgrademax;
    }
  }
  if($grade192 > 0){
    foreach ($grade192 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total192 = $rawgrade * $rawgrademax;
    }
  }
  if($grade193 > 0){
    foreach ($grade193 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total193 = $rawgrade * $rawgrademax;
    }
  }
  if($grade194 > 0){
    foreach ($grade194 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total194 = $rawgrade * $rawgrademax;
    }
  }
  if($grade195 > 0){
    foreach ($grade195 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total195 = $rawgrade * $rawgrademax;
    }
  }
      ?>
       var ctx4 = document.getElementById("mybarChart4");
      var mybarChart4 = new Chart(ctx4, {
        type: 'bar',
        data: {
          labels: ["Filipino", "English", "Mathematics", "Araling Panlipunan" ,"Science"],
          datasets: [{
               label: '<?=$fname?>',
            backgroundColor: "#4F81BC",
            data: [<?=$total11;?>, <?=$total12;?>, <?=$total13;?>, <?=$total14;?>,<?=$total15;?>]
          }, {
            label: '<?=$fname2?>',
            backgroundColor: "#C0504E",
            data: [<?=$total31;?>, <?=$total32;?>, <?=$total33;?>, <?=$total34;?>,<?=$total35;?>]
          },
          {
            label: '<?=$fname3;?>',
            backgroundColor: "#9BBB58",
             data: [<?=$total51;?>, <?=$total52;?>, <?=$total53;?>, <?=$total54;?>,<?=$total55;?>]
          },
          {
            label: '<?=$fname4;?>',
             backgroundColor: "#23BFAA",
             data: [<?=$total71;?>, <?=$total72;?>, <?=$total73;?>, <?=$total74;?>,<?=$total75;?>]
          },
          {
            label: '<?=$fname5;?>',
           backgroundColor: "#8064A1",
            data: [<?=$total91;?>, <?=$total92;?>, <?=$total93;?>, <?=$total94;?>,<?=$total95;?>]
          },
          {
            label: '<?=$fname6;?>',
           backgroundColor: "#4AACC5",
            data: [<?=$total11;?>, <?=$total112;?>, <?=$total113;?>, <?=$total114;?>,<?=$total115;?>]
          },
          {
            label: '<?=$fname7;?>',
            backgroundColor: "#F5923E",
             data: [<?=$total31;?>, <?=$total132;?>, <?=$total133;?>, <?=$total134;?>,<?=$total135;?>]
          },
          {
            label: '<?=$fname8;?>',
            backgroundColor: "#815E86",
             data: [<?=$total51;?>, <?=$total152;?>, <?=$total153;?>, <?=$total154;?>,<?=$total155;?>]
          },
          {
            label: '<?=$fname9;?>',
             backgroundColor: "#779F35",
            data: [<?=$total71;?>, <?=$total172;?>, <?=$total173;?>, <?=$total174;?>,<?=$total175;?>]
          },
          {
            label: '<?=$fname10;?>',
            backgroundColor: "#34558A",
             data: [<?=$total91;?>, <?=$total192;?>, <?=$total193;?>, <?=$total194;?>,<?=$total195;?>]
          }
          ]
        },

        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }]
          }
        }
      });

      <?php
         if($grade16 > 0){
    foreach ($grade16 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total16 = $rawgrade * $rawgrademax;
    }
  }
   if($grade17 > 0){
    foreach ($grade17 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total17 = $rawgrade * $rawgrademax;
    }
  }
   if($grade18 > 0){
    foreach ($grade18 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total18 = $rawgrade * $rawgrademax;
    }
  }
   if($grade19 > 0){
    foreach ($grade19 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total19 = $rawgrade * $rawgrademax;
    }
  }
   if($grade20 > 0){
    foreach ($grade20 as $key => $value){
      $fname = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total20 = $rawgrade * $rawgrademax;
    }
  }
    if($grade36 > 0){
    foreach ($grade36 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total36 = $rawgrade * $rawgrademax;
    }
  }
  if($grade37 > 0){
    foreach ($grade37 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total37 = $rawgrade * $rawgrademax;
    }
  }
  if($grade38 > 0){
    foreach ($grade38 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total38 = $rawgrade * $rawgrademax;
    }
  }
  if($grade39 > 0){
    foreach ($grade39 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total39 = $rawgrade * $rawgrademax;
    }
  }
  if($grade40 > 0){
    foreach ($grade40 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total40 = $rawgrade * $rawgrademax;
    }
  }
    if($grade56 > 0){
    foreach ($grade56 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total56 = $rawgrade * $rawgrademax;
    }
  }
  if($grade57 > 0){
    foreach ($grade57 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total57= $rawgrade * $rawgrademax;
    }
  }
  if($grade58 > 0){
    foreach ($grade58 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total58 = $rawgrade * $rawgrademax;
    }
  }
  if($grade59 > 0){
    foreach ($grade59 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total59 = $rawgrade * $rawgrademax;
    }
  }
  if($grade60 > 0){
    foreach ($grade60 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total60 = $rawgrade * $rawgrademax;
    }
  }
  if($grade76 > 0){
    foreach ($grade76 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total76 = $rawgrade * $rawgrademax;
    }
  }
  if($grade77> 0){
    foreach ($grade77 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total77 = $rawgrade * $rawgrademax;
    }
  }
  if($grade78> 0){
    foreach ($grade78 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total78 = $rawgrade * $rawgrademax;
    }
  }
  if($grade79 > 0){
    foreach ($grade79 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total79 = $rawgrade * $rawgrademax;
    }
  }
  if($grade80 > 0){
    foreach ($grade80 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total80 = $rawgrade * $rawgrademax;
    }
  }
     if($grade96 > 0){
    foreach ($grade96 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total96 = $rawgrade * $rawgrademax;
    }
  }
     if($grade97 > 0){
    foreach ($grade97 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total97 = $rawgrade * $rawgrademax;
    }
  }
     if($grade98 > 0){
    foreach ($grade98 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total98 = $rawgrade * $rawgrademax;
    }
  }
     if($grade99 > 0){
    foreach ($grade99 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total99 = $rawgrade * $rawgrademax;
    }
  }
     if($grade100 > 0){
    foreach ($grade100 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total95= $rawgrade * $rawgrademax;
    }
  }
     if($grade100 > 0){
    foreach ($grade100 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total100 = $rawgrade * $rawgrademax;
    }
  }
    if($grade116 > 0){
    foreach ($grade116 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total116 = $rawgrade * $rawgrademax;
    }
  }
     if($grade117 > 0){
    foreach ($grade117 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total117 = $rawgrade * $rawgrademax;
    }
  }
     if($grade118 > 0){
    foreach ($grade118 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total118 = $rawgrade * $rawgrademax;
    }
  }
     if($grade119 > 0){
    foreach ($grade119 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total119 = $rawgrade * $rawgrademax;
    }
  }
     if($grade120 > 0){
    foreach ($grade120 as $key => $value){
      $fname6 = $value['student_fname'];
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total120 = $rawgrade * $rawgrademax;
    }
  }
    if($grade136 > 0){
    foreach ($grade136 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total136= $rawgrade * $rawgrademax;
    }
  }
  if($grade137 > 0){
    foreach ($grade137 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total137= $rawgrade * $rawgrademax;
    }
  }
  if($grade138 > 0){
    foreach ($grade138 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total138= $rawgrade * $rawgrademax;
    }
  }
  if($grade139 > 0){
    foreach ($grade139 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total139 = $rawgrade * $rawgrademax;
    }
  }
  if($grade140 > 0){
    foreach ($grade140 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total140 = $rawgrade * $rawgrademax;
    }
  }
      if($grade156 > 0){
    foreach ($grade156 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total156 = $rawgrade * $rawgrademax;
    }
  }
  if($grade157 > 0){
    foreach ($grade157 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total157 = $rawgrade * $rawgrademax;
    }
  }
   if($grade158 > 0){
    foreach ($grade158 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total158 = $rawgrade * $rawgrademax;
    }
  }
   if($grade159 > 0){
    foreach ($grade159 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total159 = $rawgrade * $rawgrademax;
    }
  }
   if($grade160 > 0){
    foreach ($grade160 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total160 = $rawgrade * $rawgrademax;
    }
  }
      if($grade176 > 0){
    foreach ($grade176 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total176 = $rawgrade * $rawgrademax;
    }
  }
   if($grade177 > 0){
    foreach ($grade177 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total177 = $rawgrade * $rawgrademax;
    }
  }
   if($grade178 > 0){
    foreach ($grade178 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total178 = $rawgrade * $rawgrademax;
    }
  }
  if($grade179 > 0){
    foreach ($grade179 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total179 = $rawgrade * $rawgrademax;
    }
  }
   if($grade180 > 0){
    foreach ($grade180 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total180 = $rawgrade * $rawgrademax;
    }
  }
   if($grade196 > 0){
    foreach ($grade196 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total196 = $rawgrade * $rawgrademax;
    }
  }
  if($grade197 > 0){
    foreach ($grade197 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total197 = $rawgrade * $rawgrademax;
    }
  }
  if($grade198 > 0){
    foreach ($grade198 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total198 = $rawgrade * $rawgrademax;
    }
  }
  if($grade199 > 0){
    foreach ($grade199 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total199 = $rawgrade * $rawgrademax;
    }
  }
if($grade200 > 0){
    foreach ($grade200 as $key => $value){
      $rawgrade = $value['rawgrade'];
      $rawgrademax = $value['rawgrademax'];

      $total200 = $rawgrade * $rawgrademax;
    }
  }
      ?>
       var ctx5 = document.getElementById("mybarChart5");
      var mybarChart5 = new Chart(ctx5, {
        type: 'bar',
        data: {
          labels: ["Filipino", "English", "Mathematics", "Araling Panlipunan","Science"],
          datasets: [{
            label: '<?=$fname;?>',
            backgroundColor: "#4F81BC",
            data: [<?=$total16;?>, <?=$total17;?>, <?=$total18;?>, <?=$total19;?>,<?=$total20;?>]
          }, {
            label: '<?=$fname2;?>',
            backgroundColor: "#C0504E",
            data: [<?=$total36;?>, <?=$total37;?>, <?=$total38;?>, <?=$total39;?>,<?=$total40;?>]
          },
          {
            label: '<?=$fname3;?>',
            backgroundColor: "#9BBB58",
             data: [<?=$total56;?>, <?=$total57;?>, <?=$total58;?>, <?=$total59;?>,<?=$total60;?>]
          },
          {
            label: '<?=$fname4;?>',
            backgroundColor: "#23BFAA",
             data: [<?=$total76;?>, <?=$total77;?>, <?=$total78;?>, <?=$total79;?>,<?=$total80;?>]
          },
          {
            label: '<?=$fname5;?>',
            backgroundColor: "#8064A1",
             data: [<?=$total96;?>, <?=$total97;?>, <?=$total98;?>, <?=$total99;?>,<?=$total100;?>]
          },
          {
           label: '<?=$fname6;?>',
           backgroundColor: "#4AACC5",
             data: [<?=$total116;?>, <?=$total117;?>, <?=$total118;?>, <?=$total119;?>,<?=$total120;?>]
          },
          {
            label: '<?=$fname7;?>',
            backgroundColor: "#F5923E",
              data: [<?=$total136;?>, <?=$total137;?>, <?=$total138;?>, <?=$total139;?>,<?=$total140;?>]
          },
          {
            label: '<?=$fname8;?>',
           backgroundColor: "#815E86",
             data: [<?=$total156;?>, <?=$total157;?>, <?=$total158;?>, <?=$total159;?>,<?=$total160;?>]
          },
          {
            label: '<?=$fname9;?>',
            backgroundColor: "#779F35",
             data: [<?=$total176;?>, <?=$total177;?>, <?=$total178;?>, <?=$total179;?>,<?=$total180;?>]
          },
          {
           label: '<?=$fname10;?>',
            backgroundColor: "#34558A",
             data: [<?=$total196;?>, <?=$total197;?>, <?=$total198;?>, <?=$total199;?>,<?=$total200;?>]
          }
          ]
        },

        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }]
          }
        }
      });
</script>
</body>
</html>
