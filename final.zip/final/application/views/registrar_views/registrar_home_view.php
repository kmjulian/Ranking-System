<div class="content-wrapper">
  	<!-- Breadcrumbs-->
  	<ol class="breadcrumb">
  		<li class="breadcrumb-item">
  			<a href="#">Dashboard</a>
  		</li>

  		<li class="breadcrumb-item active">
  			"Principal"
  		</li>
  	</ol>

  	<!--Example Notifications Card-->
  	<div class="card mb-3">
  		<div class="card-header">

  		</div>
  		<div class="list-group list-group-flush small">
  			<a class="list-group-item list-group-action" href="#">
  				<div class="media">
  					<img class="d-flex mr-3 rounded-circle" width="75" height="75" src="<?php echo base_url('deped.png'); ?>" alt>
  					<div class="media-body">
  						<strong>DepEd</strong>
  						 would like to conduct a meeting with your staffs. 
  						
  						<strong></strong>
  						<div class="text-muted smaller">Today at 5:43 PM - 5m ago</div>
  					</div>
  				</div>
  			</a>
      </div>
  			<a class="list-group-item list-group-item-action" href="#">
  				<div class="media">
  					<img class="d-flex mr-3 rounded-circle" width="75" height="75" src="<?php echo base_url('aplus.png'); ?>" alt>
  					<div class="media-body">
  						A user
  						sent you a new message!
  						
  						<div class="text-muted smaller">Today at 4:37 PM - 1hr ago</div>
  					</div>
  				</div>
  </a>

</div>
</div>