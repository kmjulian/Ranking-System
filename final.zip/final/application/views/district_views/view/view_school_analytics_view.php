<style type="text/css">
	.center{
	margin-left: auto;
  	width: 92%;
	}
</style>

<div class="content-wrapper">

	<section class="content-header">
      <h1>
        School Analytics
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">View Informations</a></li>
        <li class="active">View School Analytics</li>
      </ol>
    </section>

    <div align="center"><h2>District View</h2>District 3</div>
    <section class="content">
    	<div class="row">
    		<div class="center">
    		<div class="col-md-11">
    			<canvas id="mybarChart1"></canvas>
    		</div>
    	</div>
    	</div>
    </section>
</div>