<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 3
    </div>
    <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Ranking Studio</a>.</strong> All rights
    reserved.
  </footer>

 
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>

<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/dist/js/demo.js"></script>
<!-- Chart JS-->
<script src="<?=base_url()?>public/AdminLTE-2.4.2/bower_components/chart.js/guidance chart/Chart.min.js"></script>
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : false,
      'info'        : true,
      'autoWidth'   : false
    })
  });
</script>
<script>
  <?php 
   foreach($district1 as $key => $value) {

      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total1 = $filipino * $filipinomax;
    }

     foreach($district2 as $key => $value) {

       $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total2 = $filipino * $filipinomax;
    }
     foreach($district3 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total3 = $filipino * $filipinomax;
    }
     foreach($district4 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total4 = $filipino * $filipinomax;
    }
     foreach($district5 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total5 = $filipino * $filipinomax;
    }
     foreach($district6 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total6 = $filipino * $filipinomax;
    }
     foreach($district7 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total7 = $filipino * $filipinomax;
    }
     foreach($district8 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total8 = $filipino * $filipinomax;
    }
     foreach($district9 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total9 = $filipino * $filipinomax;
    }
     foreach($district10 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total10 = $filipino * $filipinomax;
    }
     foreach($district11 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total11 = $filipino * $filipinomax;
    }
     foreach($district12 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total12 = $filipino * $filipinomax;
    }
     foreach($district13 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total13 = $filipino * $filipinomax;
    }
     foreach($district14 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total14 = $filipino * $filipinomax;
    }
     foreach($district15 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total15 = $filipino * $filipinomax;
    }
     foreach($district16 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total16 = $filipino * $filipinomax;
    }
     foreach($district17 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total17 = $filipino * $filipinomax;
    }
     foreach($district18 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total18 = $filipino * $filipinomax;
    }
     foreach($district19 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total19 = $filipino * $filipinomax;
    }
     foreach($district20 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total20 = $filipino * $filipinomax;
    }

    $fil = ($total1 + $total6 + $total11 + $total16) / 4;
    $eng = ($total2 + $total7 + $total12 + $total17) / 4;
    $math = ($total3 + $total8 + $total13 + $total18) / 4;
    $sci = ($total4 + $total9 + $total14 + $total19) / 4;
    $ap = ($total5 + $total10 + $total15 + $total20) / 4;
  
// District 2
   foreach($district21 as $key => $value) {

      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total21 = $filipino * $filipinomax;
    }

     foreach($district22 as $key => $value) {

       $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total22 = $filipino * $filipinomax;
    }
     foreach($district23 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total23 = $filipino * $filipinomax;
    }
     foreach($district24 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total24 = $filipino * $filipinomax;
    }
     foreach($district25 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total25 = $filipino * $filipinomax;
    }
     foreach($district26 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total26 = $filipino * $filipinomax;
    }
     foreach($district27 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total27 = $filipino * $filipinomax;
    }
     foreach($district28 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total28 = $filipino * $filipinomax;
    }
     foreach($district29 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total29 = $filipino * $filipinomax;
    }
     foreach($district30 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total30 = $filipino * $filipinomax;
    }
     foreach($district31 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total31 = $filipino * $filipinomax;
    }
     foreach($district32 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total32 = $filipino * $filipinomax;
    }
     foreach($district33 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total33 = $filipino * $filipinomax;
    }
     foreach($district34 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total34 = $filipino * $filipinomax;
    }
     foreach($district35 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total35 = $filipino * $filipinomax;
    }
     foreach($district36 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total36 = $filipino * $filipinomax;
    }
     foreach($district37 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total37 = $filipino * $filipinomax;
    }
     foreach($district38 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total38 = $filipino * $filipinomax;
    }
     foreach($district39 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total39 = $filipino * $filipinomax;
    }
     foreach($district40 as $key => $value) {
      $filipino = $value['t_grade'];
      $filipinomax = $value['max_grade'];
      $total40 = $filipino * $filipinomax;
    }

    $fil1 = ($total21 + $total26 + $total31 + $total36) / 4;
    $eng1 = ($total22 + $total27 + $total32 + $total37) / 4;
    $math1 = ($total23 + $total28 + $total33 + $total38) / 4;
    $sci1 = ($total24 + $total29 + $total34 + $total39) / 4;
    $ap1 = ($total25 + $total30 + $total35 + $total40) / 4;

  ?>
  var gov_dist1 = document.getElementById("mybarChart1");
      var mybarChart1 = new Chart(gov_dist1, {
        type: 'bar',
        data: {
          labels: ["Filipino", "English", "Mathematics", "Science", "Araling Panlipunan"],
          datasets: [{
            label: 'Bangkal Main',
            backgroundColor: "#4472C7",
            data: [<?=$fil?>, <?=$eng?>, <?=$math?>, <?=$sci?>, <?=$ap?>]
          },
          {
            label: 'Bangkal 2',
            backgroundColor: "#EE7E32",
            data: [<?=$fil1?>, <?=$eng1?>, <?=$math1?>, <?=$sci1?>, <?=$ap1?>]
          }
          ]
        },

        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }]
          }
        }
      });
</script>

</body>
</html>
