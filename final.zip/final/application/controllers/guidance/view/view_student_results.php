	
<?php

class View_Student_Results extends CI_Controller
{

	public function __construct()
	{
		parent:: __construct();
		$this->load->model('guidance/view/view_section_result_model');
		$this->load->model('login_model');
	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		$Schoolid = $sess_data['SchoolID'];


		
		if($position == 'guidance' || $position == 'Guidance')
		{


/*
		$school = $this->view_section_result_model->get_school($Schoolid);
		$section = $this->view_section_result_model->get_section($school);
		$students = $this->view_section_result_model->get_students($section);
		$grade = $this->view_section_result_model->get_grades($students);
		$data['grades'] = $this->view_section_result_model->filigrade($grade);
	*/	



			$data['result'] = $this->view_section_result_model->get_student_result($userid, $Schoolid);

			
			$this->load->view('guidance_views/header');
			$this->load->view('guidance_views/view/view_student_results_view', $data);
			$this->load->view('guidance_views/footer');
		}
		else
		{
			redirect('login', 'refresh');
		}
	}

	function result()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		$Schoolid = $sess_data['SchoolID'];
		$this->view_student_result_model->get_student_result($userid, $Schoolid);
		
	}

	function filipinogrades()
	{

		$Schoolid = $sess_data['SchoolID'];
		$school = $this->view_section_result_model->get_school($Schoolid);
		$section = $this->view_section_result_model->get_section($school);
		$students = $this->view_section_result_model->get_students($section);
		$grade = $this->view_section_result_model->get_grades($students);
		$data['grades'] = $this->view_section_result_model->filigrade($grade);
		
		$this->load->view('guidance_views/view/view_student_results_view',$data);


	}
}