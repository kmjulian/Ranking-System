<?php

class View_Student_Profile extends CI_Controller
{

	public function __construct()
	{
		parent:: __construct();
		$this->load->model('guidance/view/view_student_users_model');
	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		$sid = $sess_data['SchoolID'];
		$this->view_student_users_model->select_accounts($sid);
		
		if($position == 'Guidance' || $position == 'guidance')
		{
			$data['list'] = $this->view_student_users_model->select_accounts($sid);
			$this->load->view('guidance_views/header');
			$this->load->view('guidance_views/view/view_student_profile_view', $data);
			$this->load->view('guidance_views/footer');
		}
		else
		{
			redirect('login', 'refresh');
		}
	}
}