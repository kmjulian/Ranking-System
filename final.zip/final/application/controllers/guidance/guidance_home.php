<?php

class Guidance_Home extends CI_Controller
{
	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'Guidance' || $position == 'guidance')
		{
			$this->load->view('guidance_views/header');
			$this->load->view('guidance_views/guidance_home_view');
			$this->load->view('guidance_views/footer');
		}
		else
		{
			redirect('login','refresh');
		}
	}
}