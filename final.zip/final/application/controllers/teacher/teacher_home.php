<?php

class Teacher_Home extends CI_Controller
{
	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'Teacher' || $position == 'Teacher')
		{
			$this->load->view('teacher_views/header');
			$this->load->view('teacher_views/teacher_home_view');
			$this->load->view('teacher_views/footer');
		}
		else
		{
			redirect('login','refresh');
		}
	}
}