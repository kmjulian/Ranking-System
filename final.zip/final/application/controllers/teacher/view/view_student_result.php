<?php

class View_Student_Result extends CI_Controller
{
	function index()
	{
		$this->load->view('teacher_views/header');
		$this->load->view('teacher_views/view/view_student_result_view');
		$this->load->view('teacher_views/footer');
	}
}