<?php

class View_Student_Result extends CI_Controller
{

	public function __construct()
	{
		parent:: __construct();
	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		$sid = $sess_data['SchoolID'];
		$this->view_school_user_model->select_accounts($sid);
		
		if($position == 'Registrar' || $position == 'registrar')
		{
			$data['list'] = $this->view_school_user_model->select_accounts($sid);
			$this->load->view('registrar_views/header');
			$this->load->view('registrar_views/view/view_school_users_view', $data);
			$this->load->view('registrar_views/footer');
		}
		else
		{
			redirect('login', 'refresh');
		}
	}
}