<?php

class View_Student_Profile extends CI_Controller
{

	public function __construct()
	{
		parent:: __construct();
		$this->load->model('teacher/view/view_student_profile_model');
	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		$sid = $sess_data['SchoolID'];
		
		if($position == 'Teacher' || $position == 'teacher')
		{
			$data['list'] = $this->view_student_profile_model->select_accounts($userid);
			$this->load->view('teacher_views/header');
			$this->load->view('teacher_views/view/view_student_profile_view', $data);
			$this->load->view('teacher_views/footer');
		}
		else
		{
			redirect('login', 'refresh');
		}
	}
}