<?php

class View_Student_Analytics extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('teacher/view/view_student_analytics_model');
    	$this->load->model('login_model');
	}
	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		if($position == 'Teacher' || $position == 'teacher')
		{
		$data['grade1'] = $this->view_student_analytics_model->get_exam_details1($userid);
		$data['grade2'] = $this->view_student_analytics_model->get_exam_details2($userid);
		$data['grade3'] = $this->view_student_analytics_model->get_exam_details3($userid);
		$data['grade4'] = $this->view_student_analytics_model->get_exam_details4($userid);
		$data['grade5'] = $this->view_student_analytics_model->get_exam_details5($userid);
		$data['grade6'] = $this->view_student_analytics_model->get_exam_details6($userid);
		$data['grade7'] = $this->view_student_analytics_model->get_exam_details7($userid);
		$data['grade8'] = $this->view_student_analytics_model->get_exam_details8($userid);
		$data['grade9'] = $this->view_student_analytics_model->get_exam_details9($userid);
		$data['grade10'] = $this->view_student_analytics_model->get_exam_details10($userid);

		$data['grade11'] = $this->view_student_analytics_model->get_exam_details11($userid);
		$data['grade12'] = $this->view_student_analytics_model->get_exam_details12($userid);
		$data['grade13'] = $this->view_student_analytics_model->get_exam_details13($userid);
		$data['grade14'] = $this->view_student_analytics_model->get_exam_details14($userid);
		$data['grade15'] = $this->view_student_analytics_model->get_exam_details15($userid);
		$data['grade16'] = $this->view_student_analytics_model->get_exam_details16($userid);
		$data['grade17'] = $this->view_student_analytics_model->get_exam_details17($userid);
		$data['grade18'] = $this->view_student_analytics_model->get_exam_details18($userid);
		$data['grade19'] = $this->view_student_analytics_model->get_exam_details19($userid);
		$data['grade20'] = $this->view_student_analytics_model->get_exam_details20($userid);

		$data['grade21'] = $this->view_student_analytics_model->get_exam_details21($userid);
		$data['grade22'] = $this->view_student_analytics_model->get_exam_details22($userid);
		$data['grade23'] = $this->view_student_analytics_model->get_exam_details23($userid);
		$data['grade24'] = $this->view_student_analytics_model->get_exam_details24($userid);
		$data['grade25'] = $this->view_student_analytics_model->get_exam_details25($userid);
		$data['grade26'] = $this->view_student_analytics_model->get_exam_details26($userid);
		$data['grade27'] = $this->view_student_analytics_model->get_exam_details27($userid);
		$data['grade28'] = $this->view_student_analytics_model->get_exam_details28($userid);
		$data['grade29'] = $this->view_student_analytics_model->get_exam_details29($userid);
		$data['grade30'] = $this->view_student_analytics_model->get_exam_details30($userid);

		$data['grade31'] = $this->view_student_analytics_model->get_exam_details31($userid);
		$data['grade32'] = $this->view_student_analytics_model->get_exam_details32($userid);
		$data['grade33'] = $this->view_student_analytics_model->get_exam_details33($userid);
		$data['grade34'] = $this->view_student_analytics_model->get_exam_details34($userid);
		$data['grade35'] = $this->view_student_analytics_model->get_exam_details35($userid);
		$data['grade36'] = $this->view_student_analytics_model->get_exam_details36($userid);
		$data['grade37'] = $this->view_student_analytics_model->get_exam_details37($userid);
		$data['grade38'] = $this->view_student_analytics_model->get_exam_details38($userid);
		$data['grade39'] = $this->view_student_analytics_model->get_exam_details39($userid);
		$data['grade40'] = $this->view_student_analytics_model->get_exam_details40($userid);
		
		$data['grade41'] = $this->view_student_analytics_model->get_exam_details41($userid);
		$data['grade42'] = $this->view_student_analytics_model->get_exam_details42($userid);
		$data['grade43'] = $this->view_student_analytics_model->get_exam_details43($userid);
		$data['grade44'] = $this->view_student_analytics_model->get_exam_details44($userid);
		$data['grade45'] = $this->view_student_analytics_model->get_exam_details45($userid);
		$data['grade46'] = $this->view_student_analytics_model->get_exam_details46($userid);
		$data['grade47'] = $this->view_student_analytics_model->get_exam_details47($userid);
		$data['grade48'] = $this->view_student_analytics_model->get_exam_details48($userid);
		$data['grade49'] = $this->view_student_analytics_model->get_exam_details49($userid);
		$data['grade50'] = $this->view_student_analytics_model->get_exam_details50($userid);

		$data['grade51'] = $this->view_student_analytics_model->get_exam_details51($userid);
		$data['grade52'] = $this->view_student_analytics_model->get_exam_details52($userid);
		$data['grade53'] = $this->view_student_analytics_model->get_exam_details53($userid);
		$data['grade54'] = $this->view_student_analytics_model->get_exam_details54($userid);
		$data['grade55'] = $this->view_student_analytics_model->get_exam_details55($userid);
		$data['grade56'] = $this->view_student_analytics_model->get_exam_details56($userid);
		$data['grade57'] = $this->view_student_analytics_model->get_exam_details57($userid);
		$data['grade58'] = $this->view_student_analytics_model->get_exam_details58($userid);
		$data['grade59'] = $this->view_student_analytics_model->get_exam_details59($userid);
		$data['grade60'] = $this->view_student_analytics_model->get_exam_details60($userid);

		$data['grade61'] = $this->view_student_analytics_model->get_exam_details61($userid);
		$data['grade62'] = $this->view_student_analytics_model->get_exam_details62($userid);
		$data['grade63'] = $this->view_student_analytics_model->get_exam_details63($userid);
		$data['grade64'] = $this->view_student_analytics_model->get_exam_details64($userid);
		$data['grade65'] = $this->view_student_analytics_model->get_exam_details65($userid);
		$data['grade66'] = $this->view_student_analytics_model->get_exam_details66($userid);
		$data['grade67'] = $this->view_student_analytics_model->get_exam_details67($userid);
		$data['grade68'] = $this->view_student_analytics_model->get_exam_details68($userid);
		$data['grade69'] = $this->view_student_analytics_model->get_exam_details69($userid);
		$data['grade70'] = $this->view_student_analytics_model->get_exam_details70($userid);

		$data['grade71'] = $this->view_student_analytics_model->get_exam_details71($userid);
		$data['grade72'] = $this->view_student_analytics_model->get_exam_details72($userid);
		$data['grade73'] = $this->view_student_analytics_model->get_exam_details73($userid);
		$data['grade74'] = $this->view_student_analytics_model->get_exam_details74($userid);
		$data['grade75'] = $this->view_student_analytics_model->get_exam_details75($userid);
		$data['grade76'] = $this->view_student_analytics_model->get_exam_details76($userid);
		$data['grade77'] = $this->view_student_analytics_model->get_exam_details77($userid);
		$data['grade78'] = $this->view_student_analytics_model->get_exam_details78($userid);
		$data['grade79'] = $this->view_student_analytics_model->get_exam_details79($userid);
		$data['grade80'] = $this->view_student_analytics_model->get_exam_details80($userid);

		$data['grade81'] = $this->view_student_analytics_model->get_exam_details81($userid);
		$data['grade82'] = $this->view_student_analytics_model->get_exam_details82($userid);
		$data['grade83'] = $this->view_student_analytics_model->get_exam_details83($userid);
		$data['grade84'] = $this->view_student_analytics_model->get_exam_details84($userid);
		$data['grade85'] = $this->view_student_analytics_model->get_exam_details85($userid);
		$data['grade86'] = $this->view_student_analytics_model->get_exam_details86($userid);
		$data['grade87'] = $this->view_student_analytics_model->get_exam_details87($userid);
		$data['grade88'] = $this->view_student_analytics_model->get_exam_details88($userid);
		$data['grade89'] = $this->view_student_analytics_model->get_exam_details89($userid);
		$data['grade90'] = $this->view_student_analytics_model->get_exam_details90($userid);

		$data['grade91'] = $this->view_student_analytics_model->get_exam_details91($userid);
		$data['grade92'] = $this->view_student_analytics_model->get_exam_details92($userid);
		$data['grade93'] = $this->view_student_analytics_model->get_exam_details93($userid);
		$data['grade94'] = $this->view_student_analytics_model->get_exam_details94($userid);
		$data['grade95'] = $this->view_student_analytics_model->get_exam_details95($userid);
		$data['grade96'] = $this->view_student_analytics_model->get_exam_details96($userid);
		$data['grade97'] = $this->view_student_analytics_model->get_exam_details97($userid);
		$data['grade98'] = $this->view_student_analytics_model->get_exam_details98($userid);
		$data['grade99'] = $this->view_student_analytics_model->get_exam_details99($userid);
		$data['grade100'] = $this->view_student_analytics_model->get_exam_details100($userid);		

		$data['grade101'] = $this->view_student_analytics_model->get_exam_details101($userid);
		$data['grade102'] = $this->view_student_analytics_model->get_exam_details102($userid);
		$data['grade103'] = $this->view_student_analytics_model->get_exam_details103($userid);
		$data['grade104'] = $this->view_student_analytics_model->get_exam_details104($userid);
		$data['grade105'] = $this->view_student_analytics_model->get_exam_details105($userid);
		$data['grade106'] = $this->view_student_analytics_model->get_exam_details106($userid);
		$data['grade107'] = $this->view_student_analytics_model->get_exam_details107($userid);
		$data['grade108'] = $this->view_student_analytics_model->get_exam_details108($userid);
		$data['grade109'] = $this->view_student_analytics_model->get_exam_details109($userid);
		$data['grade110'] = $this->view_student_analytics_model->get_exam_details110($userid);

		$data['grade111'] = $this->view_student_analytics_model->get_exam_details111($userid);
		$data['grade112'] = $this->view_student_analytics_model->get_exam_details112($userid);
		$data['grade113'] = $this->view_student_analytics_model->get_exam_details113($userid);
		$data['grade114'] = $this->view_student_analytics_model->get_exam_details114($userid);
		$data['grade115'] = $this->view_student_analytics_model->get_exam_details115($userid);
		$data['grade116'] = $this->view_student_analytics_model->get_exam_details116($userid);
		$data['grade117'] = $this->view_student_analytics_model->get_exam_details117($userid);
		$data['grade118'] = $this->view_student_analytics_model->get_exam_details118($userid);
		$data['grade119'] = $this->view_student_analytics_model->get_exam_details119($userid);
		$data['grade120'] = $this->view_student_analytics_model->get_exam_details120($userid);		

		$data['grade121'] = $this->view_student_analytics_model->get_exam_details121($userid);
		$data['grade122'] = $this->view_student_analytics_model->get_exam_details122($userid);
		$data['grade123'] = $this->view_student_analytics_model->get_exam_details123($userid);
		$data['grade124'] = $this->view_student_analytics_model->get_exam_details124($userid);
		$data['grade125'] = $this->view_student_analytics_model->get_exam_details125($userid);
		$data['grade126'] = $this->view_student_analytics_model->get_exam_details126($userid);
		$data['grade127'] = $this->view_student_analytics_model->get_exam_details127($userid);
		$data['grade128'] = $this->view_student_analytics_model->get_exam_details128($userid);
		$data['grade129'] = $this->view_student_analytics_model->get_exam_details129($userid);
		$data['grade130'] = $this->view_student_analytics_model->get_exam_details130($userid);

		$data['grade131'] = $this->view_student_analytics_model->get_exam_details131($userid);
		$data['grade132'] = $this->view_student_analytics_model->get_exam_details132($userid);
		$data['grade133'] = $this->view_student_analytics_model->get_exam_details133($userid);
		$data['grade134'] = $this->view_student_analytics_model->get_exam_details134($userid);
		$data['grade135'] = $this->view_student_analytics_model->get_exam_details135($userid);
		$data['grade136'] = $this->view_student_analytics_model->get_exam_details136($userid);
		$data['grade137'] = $this->view_student_analytics_model->get_exam_details137($userid);
		$data['grade138'] = $this->view_student_analytics_model->get_exam_details138($userid);
		$data['grade139'] = $this->view_student_analytics_model->get_exam_details139($userid);
		$data['grade140'] = $this->view_student_analytics_model->get_exam_details140($userid);	

		$data['grade141'] = $this->view_student_analytics_model->get_exam_details141($userid);
		$data['grade142'] = $this->view_student_analytics_model->get_exam_details142($userid);
		$data['grade143'] = $this->view_student_analytics_model->get_exam_details143($userid);
		$data['grade144'] = $this->view_student_analytics_model->get_exam_details144($userid);
		$data['grade145'] = $this->view_student_analytics_model->get_exam_details145($userid);
		$data['grade146'] = $this->view_student_analytics_model->get_exam_details146($userid);
		$data['grade147'] = $this->view_student_analytics_model->get_exam_details147($userid);
		$data['grade148'] = $this->view_student_analytics_model->get_exam_details148($userid);
		$data['grade149'] = $this->view_student_analytics_model->get_exam_details149($userid);
		$data['grade150'] = $this->view_student_analytics_model->get_exam_details150($userid);

		$data['grade151'] = $this->view_student_analytics_model->get_exam_details151($userid);
		$data['grade152'] = $this->view_student_analytics_model->get_exam_details152($userid);
		$data['grade153'] = $this->view_student_analytics_model->get_exam_details153($userid);
		$data['grade154'] = $this->view_student_analytics_model->get_exam_details154($userid);
		$data['grade155'] = $this->view_student_analytics_model->get_exam_details155($userid);
		$data['grade156'] = $this->view_student_analytics_model->get_exam_details156($userid);
		$data['grade157'] = $this->view_student_analytics_model->get_exam_details157($userid);
		$data['grade158'] = $this->view_student_analytics_model->get_exam_details158($userid);
		$data['grade159'] = $this->view_student_analytics_model->get_exam_details159($userid);
		$data['grade160'] = $this->view_student_analytics_model->get_exam_details160($userid);	

		$data['grade161'] = $this->view_student_analytics_model->get_exam_details161($userid);
		$data['grade162'] = $this->view_student_analytics_model->get_exam_details162($userid);
		$data['grade163'] = $this->view_student_analytics_model->get_exam_details163($userid);
		$data['grade164'] = $this->view_student_analytics_model->get_exam_details164($userid);
		$data['grade165'] = $this->view_student_analytics_model->get_exam_details165($userid);
		$data['grade166'] = $this->view_student_analytics_model->get_exam_details166($userid);
		$data['grade167'] = $this->view_student_analytics_model->get_exam_details167($userid);
		$data['grade168'] = $this->view_student_analytics_model->get_exam_details168($userid);
		$data['grade169'] = $this->view_student_analytics_model->get_exam_details169($userid);
		$data['grade170'] = $this->view_student_analytics_model->get_exam_details170($userid);

		$data['grade171'] = $this->view_student_analytics_model->get_exam_details171($userid);
		$data['grade172'] = $this->view_student_analytics_model->get_exam_details172($userid);
		$data['grade173'] = $this->view_student_analytics_model->get_exam_details173($userid);
		$data['grade174'] = $this->view_student_analytics_model->get_exam_details174($userid);
		$data['grade175'] = $this->view_student_analytics_model->get_exam_details175($userid);
		$data['grade176'] = $this->view_student_analytics_model->get_exam_details176($userid);
		$data['grade177'] = $this->view_student_analytics_model->get_exam_details177($userid);
		$data['grade178'] = $this->view_student_analytics_model->get_exam_details178($userid);
		$data['grade179'] = $this->view_student_analytics_model->get_exam_details179($userid);
		$data['grade180'] = $this->view_student_analytics_model->get_exam_details180($userid);

		$data['grade181'] = $this->view_student_analytics_model->get_exam_details181($userid);
		$data['grade182'] = $this->view_student_analytics_model->get_exam_details182($userid);
		$data['grade183'] = $this->view_student_analytics_model->get_exam_details183($userid);
		$data['grade184'] = $this->view_student_analytics_model->get_exam_details184($userid);
		$data['grade185'] = $this->view_student_analytics_model->get_exam_details185($userid);
		$data['grade186'] = $this->view_student_analytics_model->get_exam_details186($userid);
		$data['grade187'] = $this->view_student_analytics_model->get_exam_details187($userid);
		$data['grade188'] = $this->view_student_analytics_model->get_exam_details188($userid);
		$data['grade189'] = $this->view_student_analytics_model->get_exam_details189($userid);
		$data['grade190'] = $this->view_student_analytics_model->get_exam_details190($userid);

		$data['grade191'] = $this->view_student_analytics_model->get_exam_details191($userid);
		$data['grade192'] = $this->view_student_analytics_model->get_exam_details192($userid);
		$data['grade193'] = $this->view_student_analytics_model->get_exam_details193($userid);
		$data['grade194'] = $this->view_student_analytics_model->get_exam_details194($userid);
		$data['grade195'] = $this->view_student_analytics_model->get_exam_details195($userid);
		$data['grade196'] = $this->view_student_analytics_model->get_exam_details196($userid);
		$data['grade197'] = $this->view_student_analytics_model->get_exam_details197($userid);
		$data['grade198'] = $this->view_student_analytics_model->get_exam_details198($userid);
		$data['grade199'] = $this->view_student_analytics_model->get_exam_details199($userid);
		$data['grade200'] = $this->view_student_analytics_model->get_exam_details200($userid);		
		$this->load->view('teacher_views/header');
		$this->load->view('teacher_views/view/view_student_analytics_view');
		$this->load->view('teacher_views/footer', $data);
		}
		else
		{
			redirect('login','refresh');
		}

	}
}