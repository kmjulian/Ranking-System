<?php

class View_Student_Analytics extends CI_Controller
{
	function index()
	{
		$this->load->view('teacher_views/header');
		$this->load->view('teacher_views/view/view_student_analytics_view');
		$this->load->view('teacher_views/footer');
	}
}