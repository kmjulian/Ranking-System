<?php

class View_School_Results extends CI_Controller
{
	public function __construct()
    {
        parent:: __construct();
        
        $this->load->model('district/view/view_school_results_model');
        $this->load->model('login_model');
    }

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'District' || $position == 'district')
		{
		$data['result'] = $this->view_school_results_model->get_student_result();
		$this->load->view('district_views/header');
		$this->load->view('district_views/view/view_school_results_view', $data);
		$this->load->view('district_views/footer');
		}
		else
		{
		redirect('login', 'refresh');
		}
	}
}