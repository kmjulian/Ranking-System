<?php

class View_School_Analytics extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('district/view/district_analytics_model');
    	$this->load->model('login_model');
	}
	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		if($position == 'district')
		{	

		$data['district1'] = $this->district_analytics_model->get_school_grade1($userid);
		$data['district2'] = $this->district_analytics_model->get_school_grade2($userid);
		$data['district3'] = $this->district_analytics_model->get_school_grade3($userid);
		$data['district4'] = $this->district_analytics_model->get_school_grade4($userid);
		$data['district5'] = $this->district_analytics_model->get_school_grade5($userid);
		$data['district6'] = $this->district_analytics_model->get_school_grade6($userid);
		$data['district7'] = $this->district_analytics_model->get_school_grade7($userid);
		$data['district8'] = $this->district_analytics_model->get_school_grade8($userid);
		$data['district9'] = $this->district_analytics_model->get_school_grade9($userid);
		$data['district10'] = $this->district_analytics_model->get_school_grade10($userid);
		$data['district11'] = $this->district_analytics_model->get_school_grade11($userid);
		$data['district12'] = $this->district_analytics_model->get_school_grade12($userid);
		$data['district13'] = $this->district_analytics_model->get_school_grade13($userid);
		$data['district14'] = $this->district_analytics_model->get_school_grade14($userid);
		$data['district15'] = $this->district_analytics_model->get_school_grade15($userid);
		$data['district16'] = $this->district_analytics_model->get_school_grade16($userid);
		$data['district17'] = $this->district_analytics_model->get_school_grade17($userid);
		$data['district18'] = $this->district_analytics_model->get_school_grade18($userid);
		$data['district19'] = $this->district_analytics_model->get_school_grade19($userid);
		$data['district20'] = $this->district_analytics_model->get_school_grade20($userid);

		$data['district21'] = $this->district_analytics_model->get_school_grade21($userid);
		$data['district22'] = $this->district_analytics_model->get_school_grade22($userid);
		$data['district23'] = $this->district_analytics_model->get_school_grade23($userid);
		$data['district24'] = $this->district_analytics_model->get_school_grade24($userid);
		$data['district25'] = $this->district_analytics_model->get_school_grade25($userid);
		$data['district26'] = $this->district_analytics_model->get_school_grade26($userid);
		$data['district27'] = $this->district_analytics_model->get_school_grade27($userid);
		$data['district28'] = $this->district_analytics_model->get_school_grade28($userid);
		$data['district29'] = $this->district_analytics_model->get_school_grade29($userid);
		$data['district30'] = $this->district_analytics_model->get_school_grade30($userid);
		$data['district31'] = $this->district_analytics_model->get_school_grade31($userid);
		$data['district32'] = $this->district_analytics_model->get_school_grade32($userid);
		$data['district33'] = $this->district_analytics_model->get_school_grade33($userid);
		$data['district34'] = $this->district_analytics_model->get_school_grade34($userid);
		$data['district35'] = $this->district_analytics_model->get_school_grade35($userid);
		$data['district36'] = $this->district_analytics_model->get_school_grade36($userid);
		$data['district37'] = $this->district_analytics_model->get_school_grade37($userid);
		$data['district38'] = $this->district_analytics_model->get_school_grade38($userid);
		$data['district39'] = $this->district_analytics_model->get_school_grade39($userid);
		$data['district40'] = $this->district_analytics_model->get_school_grade40($userid);
		
		$this->load->view('district_views/header');
		$this->load->view('district_views/view/view_school_analytics_view');
		$this->load->view('district_views/footer', $data);
	}
	else
	{
		redirect('login','refresh');
	}
	}
}