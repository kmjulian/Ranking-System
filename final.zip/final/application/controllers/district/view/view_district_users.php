<?php

class View_District_Users extends CI_Controller
{
	public function __construct()
    {
        parent:: __construct();
        
        $this->load->model('district/view/view_district_users_model');
        $this->load->model('login_model');
    }

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'District' || $position == 'district')
		{
			$data['list'] = $this->view_district_users_model->select_accounts();
			$this->load->view('district_views/header');
			$this->load->view('district_views/view/view_district_users_view', $data);
			$this->load->view('district_views/footer');
		}
		else
		{
			redirect('login','refresh');
		}
	}
}