<?php

class View_School_Users extends CI_Controller
{

	function __construct()
	{
		parent:: __construct();
		$this->load->model('principal/view/view_school_user_model');
	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		$sid = $sess_data['SchoolID'];
		$this->view_school_user_model->select_accounts($sid);
		
		if($position == 'Principal' || $position == 'principal')
		{
			$data['list'] = $this->view_school_user_model->select_accounts($sid);
			$this->load->view('principal_views/header');
			$this->load->view('principal_views/view/view_school_users_view', $data);
			$this->load->view('principal_views/footer');
		}
		else
		{
			redirect('login', 'refresh');
		}
	}
}