<?php

class View_School_Results extends CI_Controller
{
	public function __construct()
	{
		parent:: __construct();
		$this->load->model('principal/view/view_school_result_model');
		$this->load->model('login_model');
	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		$Schoolid = $sess_data['SchoolID'];


		
		if($position == 'principal' || $position == 'Principal')
		{


		$data['result'] = $this->view_school_result_model->get_student_result($userid, $Schoolid);
		$this->load->view('principal_views/header');
		$this->load->view('principal_views/view/view_school_results_view', $data);
		$this->load->view('principal_views/footer');
		}
		else
		{
			redirect('login', 'refresh');
		}
	}

	
}