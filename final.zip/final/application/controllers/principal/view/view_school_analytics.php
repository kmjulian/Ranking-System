<?php

class View_School_Analytics extends CI_Controller
{
	function __construct()
  	{
    	parent:: __construct();
    	$this->load->model('principal/view/view_student_analytics_model');
    	$this->load->model('login_model');
  	}
	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		if($position == 'Principal')
		{

		$data['student_analytics1'] = $this->view_student_analytics_model->grd2_I_1($userid);
		$data['student_analytics2'] = $this->view_student_analytics_model->grd2_II_2($userid);

		$data['student_analytics3'] = $this->view_student_analytics_model->grd3_I_1($userid);
		$data['student_analytics4'] = $this->view_student_analytics_model->grd3_II_2($userid);

		$data['student_analytics5'] = $this->view_student_analytics_model->grd4_I_1($userid);
		$data['student_analytics6'] = $this->view_student_analytics_model->grd4_II_2($userid);

		// $data['student_analytics2'] = $this->view_student_analytics_model->grd2_IJuan_2($userid);
		// $data['student_analytics3'] = $this->view_student_analytics_model->grd2_IJuan_3($userid);
		// $data['student_analytics4'] = $this->view_student_analytics_model->grd2_IJuan_4($userid);
		// $data['student_analytics5'] = $this->view_student_analytics_model->grd2_IJuan_5($userid);
		// $data['student_analytics6'] = $this->view_student_analytics_model->grd2_IJuan_6($userid);
		// $data['student_analytics7'] = $this->view_student_analytics_model->grd2_IJuan_7($userid);
		// $data['student_analytics8'] = $this->view_student_analytics_model->grd2_IJuan_8($userid);
		// $data['student_analytics9'] = $this->view_student_analytics_model->grd2_IJuan_9($userid);
		// $data['student_analytics10'] = $this->view_student_analytics_model->grd2_IJuan_10($userid);
		// $data['student_analytics11'] = $this->view_student_analytics_model->grd2_IJuan_11($userid);
		// $data['student_analytics12'] = $this->view_student_analytics_model->grd2_IJuan_12($userid);
		// $data['student_analytics13'] = $this->view_student_analytics_model->grd2_IJuan_13($userid);
		// $data['student_analytics14'] = $this->view_student_analytics_model->grd2_IJuan_14($userid);
		// $data['student_analytics15'] = $this->view_student_analytics_model->grd2_IJuan_15($userid);
		// $data['student_analytics16'] = $this->view_student_analytics_model->grd2_IJuan_16($userid);
		// $data['student_analytics17'] = $this->view_student_analytics_model->grd2_IJuan_17($userid);
		// $data['student_analytics18'] = $this->view_student_analytics_model->grd2_IJuan_18($userid);
		// $data['student_analytics19'] = $this->view_student_analytics_model->grd2_IJuan_19($userid);
		// $data['student_analytics20'] = $this->view_student_analytics_model->grd2_IJuan_20($userid);
		// $data['student_analytics21'] = $this->view_student_analytics_model->grd2_IJuan_21($userid);
		// $data['student_analytics22'] = $this->view_student_analytics_model->grd2_IJuan_22($userid);
		// $data['student_analytics23'] = $this->view_student_analytics_model->grd2_IJuan_23($userid);
		// $data['student_analytics24'] = $this->view_student_analytics_model->grd2_IJuan_24($userid);
		// $data['student_analytics25'] = $this->view_student_analytics_model->grd2_IJuan_25($userid);
		// $data['student_analytics26'] = $this->view_student_analytics_model->grd2_IJuan_26($userid);
		// $data['student_analytics27'] = $this->view_student_analytics_model->grd2_IJuan_27($userid);
		// $data['student_analytics28'] = $this->view_student_analytics_model->grd2_IJuan_28($userid);
		// $data['student_analytics29'] = $this->view_student_analytics_model->grd2_IJuan_29($userid);
		// $data['student_analytics30'] = $this->view_student_analytics_model->grd2_IJuan_30($userid);
		// $data['student_analytics31'] = $this->view_student_analytics_model->grd2_IJuan_31($userid);
		// $data['student_analytics32'] = $this->view_student_analytics_model->grd2_IJuan_32($userid);
		// $data['student_analytics33'] = $this->view_student_analytics_model->grd2_IJuan_33($userid);
		// $data['student_analytics34'] = $this->view_student_analytics_model->grd2_IJuan_34($userid);
		// $data['student_analytics35'] = $this->view_student_analytics_model->grd2_IJuan_35($userid);
		// $data['student_analytics36'] = $this->view_student_analytics_model->grd2_IJuan_36($userid);
		// $data['student_analytics37'] = $this->view_student_analytics_model->grd2_IJuan_37($userid);
		// $data['student_analytics38'] = $this->view_student_analytics_model->grd2_IJuan_38($userid);
		// $data['student_analytics39'] = $this->view_student_analytics_model->grd2_IJuan_39($userid);
		// $data['student_analytics40'] = $this->view_student_analytics_model->grd2_IJuan_40($userid);
		// $data['student_analytics41'] = $this->view_student_analytics_model->grd2_IJuan_41($userid);
		// $data['student_analytics42'] = $this->view_student_analytics_model->grd2_IJuan_42($userid);
		// $data['student_analytics43'] = $this->view_student_analytics_model->grd2_IJuan_43($userid);
		// $data['student_analytics44'] = $this->view_student_analytics_model->grd2_IJuan_44($userid);
		// $data['student_analytics45'] = $this->view_student_analytics_model->grd2_IJuan_45($userid);
		// $data['student_analytics46'] = $this->view_student_analytics_model->grd2_IJuan_46($userid);
		// $data['student_analytics47'] = $this->view_student_analytics_model->grd2_IJuan_47($userid);
		// $data['student_analytics48'] = $this->view_student_analytics_model->grd2_IJuan_48($userid);
		// $data['student_analytics49'] = $this->view_student_analytics_model->grd2_IJuan_49($userid);
		// $data['student_analytics50'] = $this->view_student_analytics_model->grd2_IJuan_50($userid);
		// $data['student_analytics51'] = $this->view_student_analytics_model->grd2_IJuan_51($userid);
		// $data['student_analytics52'] = $this->view_student_analytics_model->grd2_IJuan_52($userid);
		// $data['student_analytics53'] = $this->view_student_analytics_model->grd2_IJuan_53($userid);
		// $data['student_analytics54'] = $this->view_student_analytics_model->grd2_IJuan_54($userid);
		// $data['student_analytics55'] = $this->view_student_analytics_model->grd2_IJuan_55($userid);
		// $data['student_analytics56'] = $this->view_student_analytics_model->grd2_IJuan_56($userid);
		// $data['student_analytics57'] = $this->view_student_analytics_model->grd2_IJuan_57($userid);
		// $data['student_analytics58'] = $this->view_student_analytics_model->grd2_IJuan_58($userid);
		// $data['student_analytics59'] = $this->view_student_analytics_model->grd2_IJuan_59($userid);
		// $data['student_analytics60'] = $this->view_student_analytics_model->grd2_IJuan_60($userid);
		// $data['student_analytics61'] = $this->view_student_analytics_model->grd2_IJuan_61($userid);
		// $data['student_analytics62'] = $this->view_student_analytics_model->grd2_IJuan_62($userid);
		// $data['student_analytics63'] = $this->view_student_analytics_model->grd2_IJuan_63($userid);
		// $data['student_analytics64'] = $this->view_student_analytics_model->grd2_IJuan_64($userid);
		// $data['student_analytics65'] = $this->view_student_analytics_model->grd2_IJuan_65($userid);
		// $data['student_analytics66'] = $this->view_student_analytics_model->grd2_IJuan_66($userid);
		// $data['student_analytics67'] = $this->view_student_analytics_model->grd2_IJuan_67($userid);
		// $data['student_analytics68'] = $this->view_student_analytics_model->grd2_IJuan_68($userid);
		// $data['student_analytics69'] = $this->view_student_analytics_model->grd2_IJuan_69($userid);
		// $data['student_analytics70'] = $this->view_student_analytics_model->grd2_IJuan_70($userid);
		// $data['student_analytics71'] = $this->view_student_analytics_model->grd2_IJuan_71($userid);
		// $data['student_analytics72'] = $this->view_student_analytics_model->grd2_IJuan_72($userid);
		// $data['student_analytics73'] = $this->view_student_analytics_model->grd2_IJuan_73($userid);
		// $data['student_analytics74'] = $this->view_student_analytics_model->grd2_IJuan_74($userid);
		// $data['student_analytics75'] = $this->view_student_analytics_model->grd2_IJuan_75($userid);
		// $data['student_analytics76'] = $this->view_student_analytics_model->grd2_IJuan_76($userid);
		// $data['student_analytics77'] = $this->view_student_analytics_model->grd2_IJuan_77($userid);
		// $data['student_analytics78'] = $this->view_student_analytics_model->grd2_IJuan_78($userid);
		// $data['student_analytics79'] = $this->view_student_analytics_model->grd2_IJuan_79($userid);
		// $data['student_analytics80'] = $this->view_student_analytics_model->grd2_IJuan_80($userid);
		// $data['student_analytics81'] = $this->view_student_analytics_model->grd2_IJuan_81($userid);
		// $data['student_analytics82'] = $this->view_student_analytics_model->grd2_IJuan_82($userid);
		// $data['student_analytics83'] = $this->view_student_analytics_model->grd2_IJuan_83($userid);
		// $data['student_analytics84'] = $this->view_student_analytics_model->grd2_IJuan_84($userid);
		// $data['student_analytics85'] = $this->view_student_analytics_model->grd2_IJuan_85($userid);
		// $data['student_analytics86'] = $this->view_student_analytics_model->grd2_IJuan_86($userid);
		// $data['student_analytics87'] = $this->view_student_analytics_model->grd2_IJuan_87($userid);
		// $data['student_analytics88'] = $this->view_student_analytics_model->grd2_IJuan_88($userid);
		// $data['student_analytics89'] = $this->view_student_analytics_model->grd2_IJuan_89($userid);
		// $data['student_analytics90'] = $this->view_student_analytics_model->grd2_IJuan_90($userid);
		// $data['student_analytics91'] = $this->view_student_analytics_model->grd2_IJuan_91($userid);
		// $data['student_analytics92'] = $this->view_student_analytics_model->grd2_IJuan_92($userid);
		// $data['student_analytics93'] = $this->view_student_analytics_model->grd2_IJuan_93($userid);
		// $data['student_analytics94'] = $this->view_student_analytics_model->grd2_IJuan_94($userid);
		// $data['student_analytics95'] = $this->view_student_analytics_model->grd2_IJuan_95($userid);
		// $data['student_analytics96'] = $this->view_student_analytics_model->grd2_IJuan_96($userid);
		// $data['student_analytics97'] = $this->view_student_analytics_model->grd2_IJuan_97($userid);
		// $data['student_analytics98'] = $this->view_student_analytics_model->grd2_IJuan_98($userid);
		// $data['student_analytics99'] = $this->view_student_analytics_model->grd2_IJuan_99($userid);
		// $data['student_analytics100'] = $this->view_student_analytics_model->grd2_IJuan_100($userid);
		// $data['student_analytics101'] = $this->view_student_analytics_model->grd2_IJuan_101($userid);
		// $data['student_analytics102'] = $this->view_student_analytics_model->grd2_IJuan_102($userid);
		// $data['student_analytics103'] = $this->view_student_analytics_model->grd2_IJuan_103($userid);
		// $data['student_analytics104'] = $this->view_student_analytics_model->grd2_IJuan_104($userid);
		// $data['student_analytics105'] = $this->view_student_analytics_model->grd2_IJuan_105($userid);
		// $data['student_analytics106'] = $this->view_student_analytics_model->grd2_IJuan_106($userid);
		// $data['student_analytics107'] = $this->view_student_analytics_model->grd2_IJuan_107($userid);
		// $data['student_analytics108'] = $this->view_student_analytics_model->grd2_IJuan_108($userid);
		// $data['student_analytics109'] = $this->view_student_analytics_model->grd2_IJuan_109($userid);
		// $data['student_analytics110'] = $this->view_student_analytics_model->grd2_IJuan_110($userid);
		// $data['student_analytics111'] = $this->view_student_analytics_model->grd2_IJuan_111($userid);
		// $data['student_analytics112'] = $this->view_student_analytics_model->grd2_IJuan_112($userid);
		// $data['student_analytics113'] = $this->view_student_analytics_model->grd2_IJuan_113($userid);
		// $data['student_analytics114'] = $this->view_student_analytics_model->grd2_IJuan_114($userid);
		// $data['student_analytics115'] = $this->view_student_analytics_model->grd2_IJuan_115($userid);
		// $data['student_analytics116'] = $this->view_student_analytics_model->grd2_IJuan_116($userid);
		// $data['student_analytics117'] = $this->view_student_analytics_model->grd2_IJuan_117($userid);
		// $data['student_analytics118'] = $this->view_student_analytics_model->grd2_IJuan_118($userid);
		// $data['student_analytics119'] = $this->view_student_analytics_model->grd2_IJuan_119($userid);
		// $data['student_analytics120'] = $this->view_student_analytics_model->grd2_IJuan_120($userid);
		// $data['student_analytics121'] = $this->view_student_analytics_model->grd2_IJuan_121($userid);
		// $data['student_analytics122'] = $this->view_student_analytics_model->grd2_IJuan_122($userid);
		// $data['student_analytics123'] = $this->view_student_analytics_model->grd2_IJuan_123($userid);
		// $data['student_analytics124'] = $this->view_student_analytics_model->grd2_IJuan_124($userid);
		// $data['student_analytics125'] = $this->view_student_analytics_model->grd2_IJuan_125($userid);
		// $data['student_analytics126'] = $this->view_student_analytics_model->grd2_IJuan_126($userid);
		// $data['student_analytics127'] = $this->view_student_analytics_model->grd2_IJuan_127($userid);
		// $data['student_analytics128'] = $this->view_student_analytics_model->grd2_IJuan_128($userid);
		// $data['student_analytics129'] = $this->view_student_analytics_model->grd2_IJuan_129($userid);
		// $data['student_analytics130'] = $this->view_student_analytics_model->grd2_IJuan_130($userid);
		// $data['student_analytics131'] = $this->view_student_analytics_model->grd2_IJuan_131($userid);
		// $data['student_analytics132'] = $this->view_student_analytics_model->grd2_IJuan_132($userid);
		// $data['student_analytics133'] = $this->view_student_analytics_model->grd2_IJuan_133($userid);
		// $data['student_analytics134'] = $this->view_student_analytics_model->grd2_IJuan_134($userid);
		// $data['student_analytics135'] = $this->view_student_analytics_model->grd2_IJuan_135($userid);
		// $data['student_analytics136'] = $this->view_student_analytics_model->grd2_IJuan_136($userid);
		// $data['student_analytics137'] = $this->view_student_analytics_model->grd2_IJuan_137($userid);
		// $data['student_analytics138'] = $this->view_student_analytics_model->grd2_IJuan_138($userid);
		// $data['student_analytics139'] = $this->view_student_analytics_model->grd2_IJuan_139($userid);
		// $data['student_analytics140'] = $this->view_student_analytics_model->grd2_IJuan_140($userid);
		// $data['student_analytics141'] = $this->view_student_analytics_model->grd2_IJuan_141($userid);
		// $data['student_analytics142'] = $this->view_student_analytics_model->grd2_IJuan_142($userid);
		// $data['student_analytics143'] = $this->view_student_analytics_model->grd2_IJuan_143($userid);
		// $data['student_analytics144'] = $this->view_student_analytics_model->grd2_IJuan_144($userid);
		// $data['student_analytics145'] = $this->view_student_analytics_model->grd2_IJuan_145($userid);
		// $data['student_analytics146'] = $this->view_student_analytics_model->grd2_IJuan_146($userid);
		// $data['student_analytics147'] = $this->view_student_analytics_model->grd2_IJuan_147($userid);
		// $data['student_analytics148'] = $this->view_student_analytics_model->grd2_IJuan_148($userid);
		// $data['student_analytics149'] = $this->view_student_analytics_model->grd2_IJuan_149($userid);
		// $data['student_analytics150'] = $this->view_student_analytics_model->grd2_IJuan_150($userid);
		// $data['student_analytics151'] = $this->view_student_analytics_model->grd2_IJuan_151($userid);
		// $data['student_analytics152'] = $this->view_student_analytics_model->grd2_IJuan_152($userid);
		// $data['student_analytics153'] = $this->view_student_analytics_model->grd2_IJuan_153($userid);
		// $data['student_analytics154'] = $this->view_student_analytics_model->grd2_IJuan_154($userid);
		// $data['student_analytics155'] = $this->view_student_analytics_model->grd2_IJuan_155($userid);
		// $data['student_analytics156'] = $this->view_student_analytics_model->grd2_IJuan_156($userid);
		// $data['student_analytics157'] = $this->view_student_analytics_model->grd2_IJuan_157($userid);
		// $data['student_analytics158'] = $this->view_student_analytics_model->grd2_IJuan_158($userid);
		// $data['student_analytics159'] = $this->view_student_analytics_model->grd2_IJuan_159($userid);
		// $data['student_analytics160'] = $this->view_student_analytics_model->grd2_IJuan_160($userid);
		// $data['student_analytics161'] = $this->view_student_analytics_model->grd2_IJuan_161($userid);
		// $data['student_analytics162'] = $this->view_student_analytics_model->grd2_IJuan_162($userid);
		// $data['student_analytics163'] = $this->view_student_analytics_model->grd2_IJuan_163($userid);
		// $data['student_analytics164'] = $this->view_student_analytics_model->grd2_IJuan_164($userid);
		// $data['student_analytics165'] = $this->view_student_analytics_model->grd2_IJuan_165($userid);
		// $data['student_analytics166'] = $this->view_student_analytics_model->grd2_IJuan_166($userid);
		// $data['student_analytics167'] = $this->view_student_analytics_model->grd2_IJuan_167($userid);
		// $data['student_analytics168'] = $this->view_student_analytics_model->grd2_IJuan_168($userid);
		// $data['student_analytics169'] = $this->view_student_analytics_model->grd2_IJuan_169($userid);
		// $data['student_analytics170'] = $this->view_student_analytics_model->grd2_IJuan_170($userid);
		// $data['student_analytics171'] = $this->view_student_analytics_model->grd2_IJuan_171($userid);
		// $data['student_analytics172'] = $this->view_student_analytics_model->grd2_IJuan_172($userid);
		// $data['student_analytics173'] = $this->view_student_analytics_model->grd2_IJuan_173($userid);
		// $data['student_analytics174'] = $this->view_student_analytics_model->grd2_IJuan_174($userid);
		// $data['student_analytics175'] = $this->view_student_analytics_model->grd2_IJuan_175($userid);
		// $data['student_analytics176'] = $this->view_student_analytics_model->grd2_IJuan_176($userid);
		// $data['student_analytics177'] = $this->view_student_analytics_model->grd2_IJuan_177($userid);
		// $data['student_analytics178'] = $this->view_student_analytics_model->grd2_IJuan_178($userid);
		// $data['student_analytics179'] = $this->view_student_analytics_model->grd2_IJuan_179($userid);
		// $data['student_analytics180'] = $this->view_student_analytics_model->grd2_IJuan_180($userid);
		// $data['student_analytics181'] = $this->view_student_analytics_model->grd2_IJuan_181($userid);
		// $data['student_analytics182'] = $this->view_student_analytics_model->grd2_IJuan_182($userid);
		// $data['student_analytics183'] = $this->view_student_analytics_model->grd2_IJuan_183($userid);
		// $data['student_analytics184'] = $this->view_student_analytics_model->grd2_IJuan_184($userid);
		// $data['student_analytics185'] = $this->view_student_analytics_model->grd2_IJuan_185($userid);
		// $data['student_analytics186'] = $this->view_student_analytics_model->grd2_IJuan_186($userid);
		// $data['student_analytics187'] = $this->view_student_analytics_model->grd2_IJuan_187($userid);
		// $data['student_analytics188'] = $this->view_student_analytics_model->grd2_IJuan_188($userid);
		// $data['student_analytics189'] = $this->view_student_analytics_model->grd2_IJuan_189($userid);
		// $data['student_analytics190'] = $this->view_student_analytics_model->grd2_IJuan_190($userid);
		// $data['student_analytics191'] = $this->view_student_analytics_model->grd2_IJuan_191($userid);
		// $data['student_analytics192'] = $this->view_student_analytics_model->grd2_IJuan_192($userid);
		// $data['student_analytics193'] = $this->view_student_analytics_model->grd2_IJuan_193($userid);
		// $data['student_analytics194'] = $this->view_student_analytics_model->grd2_IJuan_194($userid);
		// $data['student_analytics195'] = $this->view_student_analytics_model->grd2_IJuan_195($userid);
		// $data['student_analytics196'] = $this->view_student_analytics_model->grd2_IJuan_196($userid);
		// $data['student_analytics197'] = $this->view_student_analytics_model->grd2_IJuan_197($userid);
		// $data['student_analytics198'] = $this->view_student_analytics_model->grd2_IJuan_198($userid);
		// $data['student_analytics199'] = $this->view_student_analytics_model->grd2_IJuan_199($userid);
		// $data['student_analytics200'] = $this->view_student_analytics_model->grd2_IJuan_200($userid);
		
		$this->load->view('principal_views/header');
		$this->load->view('principal_views/view/view_school_analytics_view', $data);
		$this->load->view('principal_views/footer');
		}
		else
		{
			redirect('login','refresh');
		}
	}

}