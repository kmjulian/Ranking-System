<?php

class Principal_Home extends CI_Controller
{
	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'Principal' || $position == 'principal')
		{
			$this->load->view('principal_views/header');
			$this->load->view('principal_views/principal_home_view');
			$this->load->view('principal_views/footer');
		}
		else
		{
			redirect('login','refresh');
		}
	}
}