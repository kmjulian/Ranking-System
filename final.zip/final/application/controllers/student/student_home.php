<?php

class Student_Home extends CI_Controller
{
	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'Student' || $position == 'student')
		{
			$this->load->view('student_views/header');
			$this->load->view('student_views/student_home_view');
			$this->load->view('student_views/footer');
		}
		else
		{
			redirect('login','refresh');
		}
	}
}