<?php

class View_Student_analytics extends CI_Controller
{
	function __construct()
  	{
    	parent:: __construct();
    	$this->load->model('student/student_analytics_model');
    	$this->load->model('login_model');
  	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		if($position == 'Student' || $position == 'Student')
		{
			$data['student_analytics1'] = $this->student_analytics_model->get_exam_details1($userid);
			$data['student_analytics2'] = $this->student_analytics_model->get_exam_details2($userid);
			$data['student_analytics3'] = $this->student_analytics_model->get_exam_details3($userid);
			$data['student_analytics4'] = $this->student_analytics_model->get_exam_details4($userid);
			$data['student_analytics5'] = $this->student_analytics_model->get_exam_details5($userid);

			$data['student_analytics6'] = $this->student_analytics_model->get_exam_details6($userid);
			$data['student_analytics7'] = $this->student_analytics_model->get_exam_details7($userid);
			$data['student_analytics8'] = $this->student_analytics_model->get_exam_details8($userid);
			$data['student_analytics9'] = $this->student_analytics_model->get_exam_details9($userid);
			$data['student_analytics10'] = $this->student_analytics_model->get_exam_details10($userid);

			$data['student_analytics11'] = $this->student_analytics_model->get_exam_details11($userid);
			$data['student_analytics12'] = $this->student_analytics_model->get_exam_details12($userid);
			$data['student_analytics13'] = $this->student_analytics_model->get_exam_details13($userid);
			$data['student_analytics14'] = $this->student_analytics_model->get_exam_details14($userid);
			$data['student_analytics15'] = $this->student_analytics_model->get_exam_details15($userid);

			$data['student_analytics16'] = $this->student_analytics_model->get_exam_details16($userid);
			$data['student_analytics17'] = $this->student_analytics_model->get_exam_details17($userid);
			$data['student_analytics18'] = $this->student_analytics_model->get_exam_details18($userid);
			$data['student_analytics19'] = $this->student_analytics_model->get_exam_details19($userid);
			$data['student_analytics20'] = $this->student_analytics_model->get_exam_details20($userid);
		
			$this->load->view('student_views/header');
			$this->load->view('student_views/view/view_student_analytics_view');
			$this->load->view('student_views/footer', $data);
		}
		else
		{
			redirect('login','refresh');
		}
	}

	function get_student_result()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		$this->student_analytics_model->get_exam_details1($userid);
	}
}