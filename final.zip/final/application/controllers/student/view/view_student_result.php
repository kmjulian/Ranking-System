
<?php

class View_Student_Result extends CI_Controller
{
	function __construct()
  	{
    	parent:: __construct();
    	$this->load->model('student/student_result_model');
    	$this->load->model('login_model');
  	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		if($position == 'Student' || $position == 'Student')
		{
			$data['student_result'] = $this->student_result_model->get_exam_details($userid);
			
			$this->load->view('student_views/header');
			$this->load->view('student_views/view/view_student_result_view', $data);
			$this->load->view('student_views/footer');
		}
		else
		{
			redirect('login','refresh');
		}
	}

	function get_student_result()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		$this->student_result_model->get_exam_details($userid);
	}
}