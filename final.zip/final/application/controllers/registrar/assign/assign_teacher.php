<?php

class Assign_Teacher extends CI_Controller
{
	function __construct()
	{
		parent:: __construct();
		$this->load->model('registrar/assign/assign_teacher_section_model');
		$this->load->model('login_model');
	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		
		if($position == 'Registrar' || $position == 'registrar')
		{
			$data['teachers'] = $this->assign_teacher_section_model->get_teacher_name($userid);
			$data['sections'] = $this->assign_teacher_section_model->get_section_name($userid);
			$this->load->view('registrar_views/header');
			$this->load->view('registrar_views/assign/assign_teacher_view', $data);
			$this->load->view('registrar_views/footer');
		}
		else
		{
			redirect('login','refresh');
		}
	}

	function assign_teacher_account()
	{
		$Teacher = $this->input->post('teacher');
		$Section = $this->input->post('section');
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];

		$data = array('section_id' => $Section);

		$this->assign_teacher_section_model->update_teacher_section($data, $Teacher);
		$this->assign_teacher_section_model->get_teacher_name($userid);
		$this->assign_teacher_section_model->get_section_name($userid);
		redirect('registrar/assign/assign_teacher','refresh');
	}
}