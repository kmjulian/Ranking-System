<?php

class Assign_Student extends CI_Controller
{
	function __construct()
	{
		parent:: __construct();
		$this->load->model('registrar/assign/assign_student_section_model');
		$this->load->model('login_model');
	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		$userid = $sess_data['UserID'];
		
		if($position == 'Registrar' || $position == 'registrar')
		{
			$data['students'] = $this->assign_student_section_model->get_student_name($userid);
			$data['sections'] = $this->assign_student_section_model->get_section_name($userid);
			$this->load->view('registrar_views/header');
			$this->load->view('registrar_views/assign/assign_student_view', $data);
			$this->load->view('registrar_views/footer');
		}
		else
		{
			redirect('login','refresh');
		}
	}

	function assign_student_account()
	{
            // redirect('registrar/assign/assign_student','refresh');
        
        	$Student = $this->input->post('student');
        	$Section = $this->input->post('section');
        	$sess_data = $this->session->userdata('logged in');
			$position = $sess_data['Position'];
			$userid = $sess_data['UserID'];

        	$data = array(
                'section_id' => $Section,
            );

        	$this->assign_student_section_model->update_student_section($data, $Student);
        	$this->assign_student_section_model->get_student_name($userid);
        	$this->assign_student_section_model->get_section_name($userid);
        	redirect('registrar/assign/assign_student','refresh');
  	}
	
}