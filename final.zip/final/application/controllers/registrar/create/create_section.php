<?php

class Create_Section extends CI_Controller
{

	function __construct()
	{
		parent:: __construct();
		$this->load->model('registrar/create/create_section_model');
		$this->load->model('login_model');
	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'Registrar' || $position == 'registrar')
		{
			$this->load->view('registrar_views/header');
			$this->load->view('registrar_views/create/create_section_view');
			$this->load->view('registrar_views/footer');
		}
		else
		{
			redirect('login','refresh');
		}
	}

	function create_section_account()
	{
		$this->form_validation->set_rules('sname', 'Section Name', 'trim|required');
		$this->form_validation->set_rules('grade_level', 'Grade Level', 'trim|required');

		if($this->form_validation->run() == FALSE)
        {
            redirect('registrar/create/create_section','refresh');
        }
        else
        {
        	$sess_data = $this->session->userdata('logged in');
			$position = $sess_data['Position'];
			$userid = $sess_data['UserID'];
        	$sname = $this->input->post('sname');
        	$glevel = $this->input->post('grade_level');

        	$data = array(
        		'section_name' => $sname,
        		'grade_level' => $glevel
        	);

        	$this->create_section_model->insert_section_account($data, $userid);
        	redirect('registrar/create/create_section', 'refresh');

        }
	}
}