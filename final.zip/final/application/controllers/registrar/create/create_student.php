<?php

class Create_Student extends CI_Controller
{

	function __construct()
	{
		parent:: __construct();
		$this->load->model('registrar/create/create_student_model');
		$this->load->model('login_model');
	}

	function index()
	{
		$sess_data = $this->session->userdata('logged in');
		$position = $sess_data['Position'];
		if($position == 'Registrar' || $position == 'registrar')
		{
			$data['schools'] = $this->create_student_model->get_school_name();
			$this->load->view('registrar_views/header');
			$this->load->view('registrar_views/create/create_student_view', $data);
			$this->load->view('registrar_views/footer');
		}
		else
		{
			redirect('login','refresh');
		}
	}

	function create_student_account()
	{
		$this->form_validation->set_rules('fname', 'First Name', 'trim|required');
		$this->form_validation->set_rules('mname', 'Middle Name', 'trim|required');
		$this->form_validation->set_rules('lname', 'Last Name', 'trim|required');
		$this->form_validation->set_rules('address', 'Address', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'valid_email|trim|required');
		$this->form_validation->set_rules('contact', 'Contact', 'trim|required');
		$this->form_validation->set_rules('username', 'Username', 'valid_email|trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');

		if($this->form_validation->run() == FALSE)
        {
        	$message = "Register account failed; Check your inputs.";
			echo "<script type='text/javascript'>alert('$message');</script>";
            redirect('registrar/create/create_student','refresh');
        }
        else
        {
        	$sess_data = $this->session->userdata('logged in');
			$position = $sess_data['Position'];
			$userid = $sess_data['UserID'];
        	$fname = $this->input->post('fname');
        	$mname = $this->input->post('mname');
        	$lname = $this->input->post('lname');
        	$address = $this->input->post('address');
        	$email = $this->input->post('email');
        	$contact = $this->input->post('contact');
        	$username = $this->input->post('username');
        	$password = $this->input->post('password');

        	$user_details = array(
				'user_username' => $username,
				'user_password' => $password,
				'user_position' => 'Student'
		
			);

        	$data = array(
        		'student_fname' => $fname,
        		'student_mname' => $mname,
        		'student_lname' => $lname,
        		'student_district' => "3",
        		'student_address' => $address,
        		'student_email' => $email,
        		'student_contact' => $contact
        	);

        	$this->create_student_model->insert_user_account($user_details, $userid);
			$this->create_student_model->insert_student_account($data, $userid);
			$message = "You've successfully registered";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('registrar/create/create_student','refresh');

        }
	}
}