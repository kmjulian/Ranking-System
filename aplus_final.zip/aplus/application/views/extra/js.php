

  <!-- jQuery -->
  <script src="<?php echo base_url();?>scripts/jquery.js" type="text/javascript"></script>
  <script src="<?php echo base_url();?>scripts/views.js" type="text/javascript"></script>
  <!-- Bootstrap Core JavaScript -->
  <script src="<?php echo base_url();?>scripts/bootstrap.min.js" type="text/javascript"></script>
  
<script src="<?php echo base_url(); ?>scripts/jquery-1.10.2.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>scripts/jquery.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>scripts/jquery-ui.min.js" type="text/javascript"></script>