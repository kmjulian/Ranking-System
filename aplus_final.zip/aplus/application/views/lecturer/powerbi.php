<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div id="page-wrapper">
      <div class="container-fluid">
	      	<div class="text-center">
	                  <h3>Power Bi</h3>
	                  <hr>
	            </div>
	       <div class="row featurette">
              <div class="col-md-12 text-center">
              	
                <iframe width="1200" height="800" src="https://app.powerbi.com/view?r=eyJrIjoiMzU5NTQzYjktNzI2My00YjgwLWJiMTctOWYzZjNhNzJmYTRjIiwidCI6ImFlYjc0NWU2LTgxNjYtNGY4Zi05MjMzLTE3OWU4MTA5YzQ5ZSIsImMiOjEwfQ%3D%3D" frameborder="0" allowFullScreen="true"></iframe>

         </div>
</div>
</div>
</div>