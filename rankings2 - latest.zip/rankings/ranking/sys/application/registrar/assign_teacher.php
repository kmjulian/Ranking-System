<?php include 'header.php'; ?>


<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
    <div class = "card-header"><center><h2>Assign Teachers</center></h2></div><br>
	<div class="col-lg-12 well">
	<div class="row">
				
					<div class="col-sm-12" >
						<div class="row">
							<div class="col-sm-6 form-group">
								<label>Teacher</label>
								<select class="form-control">
							<option>-- Select Teacher --</option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							
								</select>
							</div>	
							<div class="col-sm-6 form-group">
								<label>Section</label>
								<select class="form-control">
							<option>-- Select Section --</option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							<option></option>
							
								</select>
							</div>	
						</div></div>
									
					<button type="button" class="btn btn-lg btn-info">Submit</button>					
					</div>	
				</div>
	</div>
	<br>
          </div>
        </div>
<?php include 'footer.php';